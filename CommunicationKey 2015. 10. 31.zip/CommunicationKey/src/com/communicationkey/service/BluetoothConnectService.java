package com.communicationkey.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;

import com.communicationkey.bluetooth.CKBluetooth;
import com.communicationkey.debug.Comm;
import com.communicationkey.fragment.DoorOpenFragment;
import com.communicationkey.fragment.NetManager;
import com.communicationkey.fragment.SettingFragment;
import com.communicationkey.item.AllTable;
import com.communicationkey.item.DBFriendItem;
import com.communicationkey.parser.JSONParser;

public class BluetoothConnectService {
	
	/* 김성곤 변수 **/
	CKBluetooth bt;
	ArrayList<AllTable> allTable = null; // 파싱한 데이터를 받아오기 위한 변수 
	// 값을 리턴하기 위한 변수를 밖으로 
	ArrayList<AllTable> friendAllInfo = new ArrayList<AllTable>();
	SharedPreferences sp = null;
	static Context context;

	// Name for the SDP record when creating server socket
	private static final String NAME = "BluetoothChat";

	// Unique UUID for this application
	private static final UUID MY_UUID = UUID
			.fromString("00001101-0000-1000-8000-00805F9B34FB");

	// Member fields
	// final은 상수인데 이 떄 가장먼저 디폴트 생성자를 호출하게 된다.
	// 근데 나같은 경우 디폴트 생성자를 주석처리 해놔서 에러가 떳었다.
	private final BluetoothAdapter mAdapter;
	// private final Handler mHandler;
	private AcceptThread mAcceptThread;
	private ConnectThread mConnectThread;
	private ConnectedThread mConnectedThread;
	private int mState;

	// Constants that indicate the current connection state
	public static final int STATE_NONE = 0; // we're doing nothing
	public static final int STATE_LISTEN = 1; // now listening for incoming connections
	public static final int STATE_CONNECTING = 2; // now initiating an outgoing connection
	public static final int STATE_CONNECTED = 3; // now connected to a remote device

	/**
	 * Constructor. Prepares a new BluetoothChat session.
	 * 
	 * @param context
	 *            The UI Activity Context
	 * @param handler
	 *            A Handler to send messages back to the UI Activity
	 */
	
	// DoorOpen에서 Context를 보내줘서 그걸 입혀
	// 서버에서 사용되지 않았을 때 Toast를 띄어주기 위함이야.
	public static void contextJoin(Context cx) {
		context = cx;
	}
	
	public BluetoothConnectService() {
		mAdapter = BluetoothAdapter.getDefaultAdapter();
		mState = STATE_NONE;
		// mHandler = handler;
	}
	
	public BluetoothConnectService(Context context) {
		mAdapter = BluetoothAdapter.getDefaultAdapter();
		mState = STATE_NONE;
		this.context = context;
	}

	/**
	 * Set the current state of the chat connection
	 * 
	 * @param state
	 *            An integer defining the current connection state
	 */
	private synchronized void setState(int state) {
		Comm.LOG("setState() " + mState + " -> " + state);
		mState = state;

		// Give the new state to the Handler so the UI Activity can update
		// mHandler.obtainMessage(BluetoothChat.MESSAGE_STATE_CHANGE, state, -1)
		// .sendToTarget();
	}

	/**
	 * Return the current connection state.
	 */
	public synchronized int getState() {
		return mState;
	}

	/**
	 * Start the chat service. Specifically start AcceptThread to begin a
	 * session in listening (server) mode. Called by the Activity onResume()
	 */
	public synchronized void start() {
		Comm.LOG("start");

		// Cancel any thread attempting to make a connection
		if (mConnectThread != null) {
			mConnectThread.cancel();
			mConnectThread = null;
		}

		// Cancel any thread currently running a connection
		if (mConnectedThread != null) {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}

		// Start the thread to listen on a BluetoothServerSocket
		if (mAcceptThread == null) {
			mAcceptThread = new AcceptThread();
			mAcceptThread.start();
		}
		setState(STATE_LISTEN);
	}

	/**
	 * Start the ConnectThread to initiate a connection to a remote device.
	 * 
	 * @param device
	 *            The BluetoothDevice to connect
	 */
	public synchronized void connect(BluetoothDevice device) {
		Comm.LOG("connect to: " + device);

		// Cancel any thread attempting to make a connection
		if (mState == STATE_CONNECTING) {
			if (mConnectThread != null) {
				mConnectThread.cancel();
				mConnectThread = null;
			}
		}

		// Cancel any thread currently running a connection
		if (mConnectedThread != null) {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}

		// Start the thread to connect with the given device
		mConnectThread = new ConnectThread(device);
		mConnectThread.start();
		setState(STATE_CONNECTING);
	}

	/**
	 * Start the ConnectedThread to begin managing a Bluetooth connection
	 * 
	 * @param socket
	 *            The BluetoothSocket on which the connection was made
	 * @param device
	 *            The BluetoothDevice that has been connected
	 */
	public synchronized void connected(BluetoothSocket socket,
			BluetoothDevice device) {
		Comm.LOG("connected");

		// Cancel the thread that completed the connection
		if (mConnectThread != null) {
			mConnectThread.cancel();
			mConnectThread = null;
		}

		// Cancel any thread currently running a connection
		if (mConnectedThread != null) {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}

		// Cancel the accept thread because we only want to connect to one
		// device
		if (mAcceptThread != null) {
			mAcceptThread.cancel();
			mAcceptThread = null;
		}

		// Start the thread to manage the connection and perform transmissions
		mConnectedThread = new ConnectedThread(socket);
		mConnectedThread.start();

		// Send the name of the connected device back to the UI Activity
		// Message msg =
		// mHandler.obtainMessage(BluetoothChat.MESSAGE_DEVICE_NAME);
		// Bundle bundle = new Bundle();
		// bundle.putString(BluetoothChat.DEVICE_NAME, device.getName());
		// msg.setData(bundle);
		// mHandler.sendMessage(msg);

		setState(STATE_CONNECTED);
	}

	/**
	 * Stop all threads
	 */
	public synchronized void stop() {
		Comm.LOG("stop");
		if (mConnectThread != null) {
			mConnectThread.cancel();
			mConnectThread = null;
		}
		if (mConnectedThread != null) {
			mConnectedThread.cancel();
			mConnectedThread = null;
		}
		if (mAcceptThread != null) {
			mAcceptThread.cancel();
			mAcceptThread = null;
		}
		setState(STATE_NONE);
	}

	/**
	 * Write to the ConnectedThread in an unsynchronized manner
	 * 
	 * @param out
	 *            The bytes to write
	 * @see ConnectedThread#write(byte[])
	 */
	public void write(byte[] out) {
		// Create temporary object
		ConnectedThread r;
		// Synchronize a copy of the ConnectedThread
		synchronized (this) {
			if (mState != STATE_CONNECTED)
				return;
			r = mConnectedThread;
		}
		// Perform the write unsynchronized
		r.write(out);
	}

	/**
	 * Indicate that the connection attempt failed and notify the UI Activity.
	 */
	private void connectionFailed() {
		setState(STATE_LISTEN);

		// Send a failure message back to the Activity
		// Message msg = mHandler.obtainMessage(BluetoothChat.MESSAGE_TOAST);
		// Bundle bundle = new Bundle();
		// bundle.putString(BluetoothChat.TOAST, "Unable to connect device");
		// msg.setData(bundle);
		// mHandler.sendMessage(msg);
	}

	/**
	 * Indicate that the connection was lost and notify the UI Activity.
	 */
	private void connectionLost() {
		setState(STATE_LISTEN);

		// Send a failure message back to the Activity
		// Message msg = mHandler.obtainMessage(BluetoothChat.MESSAGE_TOAST);
		// Bundle bundle = new Bundle();
		// bundle.putString(BluetoothChat.TOAST, "Device connection was lost");
		// msg.setData(bundle);
		// mHandler.sendMessage(msg);
	}

	/**
	 * This thread runs while listening for incoming connections. It behaves
	 * like a server-side client. It runs until a connection is accepted (or
	 * until cancelled).
	 */
	private class AcceptThread extends Thread {
		// The local server socket
		private final BluetoothServerSocket mmServerSocket;

		public AcceptThread() {
			BluetoothServerSocket tmp = null;

			// Create a new listening server socket
			try {
				tmp = mAdapter
						.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
			} catch (IOException e) {
				Comm.LOG("listen() failed" + e);
			}
			mmServerSocket = tmp;
		}

		public void run() {
			Comm.LOG("BEGIN mAcceptThread" + this);
			setName("AcceptThread");
			BluetoothSocket socket = null;

			// Listen to the server socket if we're not connected
			while (mState != STATE_CONNECTED) {
				try {
					// This is a blocking call and will only return on a
					// successful connection or an exception
					socket = mmServerSocket.accept();
				} catch (IOException e) {
					Comm.LOG("accept() failed" + e);
					break;
				}

				// If a connection was accepted
				if (socket != null) {
					synchronized (BluetoothConnectService.this) {
						switch (mState) {
						case STATE_LISTEN:
						case STATE_CONNECTING:
							// Situation normal. Start the connected thread.
							connected(socket, socket.getRemoteDevice());
							break;
						case STATE_NONE:
						case STATE_CONNECTED:
							// Either not ready or already connected. Terminate
							// new socket.
							try {
								socket.close();
							} catch (IOException e) {
								Comm.LOG("Could not close unwanted socket" + e);
							}
							break;
						}
					}
				}
			}
			Comm.LOG("END mAcceptThread");
		}

		public void cancel() {
			Comm.LOG("cancel " + this);
			try {
				mmServerSocket.close();
			} catch (IOException e) {
				Comm.LOG("close() of server failed" + e);
			}
		}
	}

	/**
	 * This thread runs while attempting to make an outgoing connection with a
	 * device. It runs straight through; the connection either succeeds or
	 * fails.
	 */
	private class ConnectThread extends Thread {
		private final BluetoothSocket mmSocket;
		private final BluetoothDevice mmDevice;

		public ConnectThread(BluetoothDevice device) {
			mmDevice = device;
			BluetoothSocket tmp = null;

			// Get a BluetoothSocket for a connection with the
			// given BluetoothDevice
			try {
				tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
			} catch (IOException e) {
				Comm.LOG("create() failed" + e);
			}
			mmSocket = tmp;
		}

		public void run() {
			Comm.LOG("BEGIN mConnectThread");
			setName("ConnectThread");

			// Always cancel discovery because it will slow down a connection
			mAdapter.cancelDiscovery();

			// Make a connection to the BluetoothSocket
			try {
				// This is a blocking call and will only return on a
				// successful connection or an exception
				mmSocket.connect();
			} catch (IOException e) {
				connectionFailed();
				// Close the socket
				try {
					mmSocket.close();
				} catch (IOException e2) {
					Comm.LOG("unable to close() socket during connection failure"
							+ e2);
				}
				// Start the service over to restart listening mode
				BluetoothConnectService.this.start();
				return;
			}

			// Reset the ConnectThread because we're done
			synchronized (BluetoothConnectService.this) {
				mConnectThread = null;
			}

			// Start the connected thread
			connected(mmSocket, mmDevice);
		}

		public void cancel() {
			try {
				mmSocket.close();
			} catch (IOException e) {
				Comm.LOG("close() of connect socket failed" + e);
			}
		}
	}

	/**
	 * This thread runs during a connection with a remote device. It handles all
	 * incoming and outgoing transmissions.
	 */
	private class ConnectedThread extends Thread {
		private final BluetoothSocket mmSocket;
		private final InputStream mmInStream;
		private final OutputStream mmOutStream;

		public ConnectedThread(BluetoothSocket socket) {
			Comm.LOG("create ConnectedThread");
			mmSocket = socket;
			InputStream tmpIn = null;
			OutputStream tmpOut = null;

			// Get the BluetoothSocket input and output streams
			try {
				tmpIn = socket.getInputStream();
				tmpOut = socket.getOutputStream();
			} catch (IOException e) {
				Comm.LOG("temp sockets not created" + e);
			}

			mmInStream = tmpIn;
			mmOutStream = tmpOut;
		}

		public void run() {
			Comm.LOG("BEGIN mConnectedThread");
			byte[] buffer = new byte[1024];
			int bytes;
			InputStream is;

			// Keep listening to the InputStream while connected
			while (true) {
				try {
					// Read from the InputStream
					bytes = mmInStream.read(buffer);

					String msg = new String(buffer, 0, bytes);
					Comm.LOG("아두이노로부터 수신된 데이터 : " + msg);

					// 아두이노에서 myHome을 보내고 싶었는데 RN-41은 보더레이트를 9600으로 해야지만
					// 보내지고 받기 때문에 그런지 몰라도 자꾸 m먼저오고 그 후 yHome이 와서 파싱이 2번되고
					// 인증이 안되는 문제가 발생 한다 그래서 그냥 임의적으로 myHome을 넘겨주는 방식으로 처리한다.
					// 원래는 이곳이 아두이노(차단기)의 각 고유 모델번호를 받아서 문을 열어주게큼 만들어야 한다.
					new ConnectDeviceTableThread("myHome").start();

					// Send the obtained bytes to the UI Activity
					// mHandler.obtainMessage(BluetoothChat.MESSAGE_READ, bytes,
					// -1, buffer).sendToTarget();
				} catch (IOException e) {
					Comm.LOG("disconnected" + e);
					connectionLost();
					break;
				}
			}
		}

		/**
		 * Write to the connected OutStream.
		 * 
		 * @param buffer
		 *            The bytes to write
		 */
		public void write(byte[] buffer) {
			try {
				mmOutStream.write(buffer);

				// Share the sent message back to the UI Activity
				// mHandler.obtainMessage(Bluetoo.MESSAGE_WRITE, -1, -1,
				// buffer).sendToTarget();
			} catch (IOException e) {
				Comm.LOG("Exception during write" + e);
			}
		}

		public void cancel() {
			try {
				mmSocket.close();
			} catch (IOException e) {
				Comm.LOG("close() of connect socket failed" + e);
			}
		}
	}

	// DeviceTable에 붙어서 userMac과 deviceId를 검색해서 True/False를 받아오는 Thread
	public class ConnectDeviceTableThread extends Thread {
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/MainControl.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;

		String arduinoMsg = null; // 아두이노의 기기값을 저장하는 스트링 
		boolean open = false; // true면 문 열어주는 함수 사용 false면 실패 
		BufferedReader br = null; // 객체를 받아오기 위함
		StringBuilder sb = null; // 받아온 데이터를 축척하기 위함 
		String line = ""; // br의 값을 한개씩 저장해서 sb에 축척함 

		List<NameValuePair> nValue = new ArrayList<NameValuePair>();

		public ConnectDeviceTableThread(String arduinoMsg) {
			this.arduinoMsg = arduinoMsg;
		}

		//스레드 본체
		@Override
		public void run() {
			try {
				allTable = new ArrayList<AllTable>();
				client = NetManager.getHttpClient();
				reqeust = NetManager.getPost(webUrl);

				// 자신의 MAC주소를 채워서 보내야지! 
				getList(arduinoMsg);
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nValue, "utf-8");
				reqeust.setEntity(entity);

				response = client.execute(reqeust);
				code = response.getStatusLine().getStatusCode();
				Comm.LOG("ConnectDeviceTableThread code : " + code);

				switch(code) {
				case 200:
					
					br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
					sb = new StringBuilder();
					
					Comm.LOG("JSON sb.toString : " + sb.toString());

					while((line = br.readLine()) != null) {
						sb.append(line);
					}

					
					
					String temp = JSONParser.getDeviceTableParser(sb.toString());
					Handler handler = new Handler(Looper.getMainLooper());
					
					if(temp.equals("doOpen")) {	
					// 출입 가능에 대한 토스틈 메세지 확인용.
						
						String data = "z";

						byte[] send = data.getBytes();
						write(send);
						
						handler.post(new Runnable() {
							@Override
							public void run() {
								Comm.TOAST(context, "문이 열렸습니다. 출입하셔도 좋습니다.");
							}
						});
					} else {
						/**토스트를 다른 곳에서 띄울 수 있게 만들어야 해!*/
						handler.post(new Runnable() {
							@Override
							public void run() {
								Comm.TOAST(context, "인증 되지 않은 사용자입니다. 출입할 수 없습니다.");
							}
						});
					}
					break;
				}
			} catch (Exception e) {
				Comm.LOG("post 전송중 에러! : " + e.getMessage());
			}
		}// end run()

		public void getList(String arduinoMsg) {
			String macAddress = "";

			if(bt == null) 
				bt = new CKBluetooth();

			/* MAC Address 출력 */
			int i = 0;
			Set<BluetoothDevice> pairedDevices = bt.doReturnAdapter()
					.getBondedDevices();
			if (pairedDevices.size() > 0) {
				for (BluetoothDevice device : pairedDevices) {
					macAddress = device.getAddress();
					// 개인의 MAC Address니까 서버에 등록해버리면 돼!
				}
			}
			/* MAC Address 출력 끝 !! */

			nValue.add(new BasicNameValuePair("deviceId", arduinoMsg));
			nValue.add(new BasicNameValuePair("userMac", macAddress));	
			nValue.add(new BasicNameValuePair("event", "connectDevice"));

			Comm.LOG(nValue + "");
		}
	}
	
	// 친구목록을 동기화 시키기 위함 우선 전화번호를 가져와야지!?
	// 전화번호 가져와서 동기화 하는데 회원가입할 떄 한번, 동기화버튼 누를 때 한번 동기화 하면 돼!
	public void synchronizationFriend(Context cx1) {
		JSONObject jObject  = null;
		JSONArray jArray = null;
		JSONObject jMain = null;
		
		Context cx = cx1;

		// 전화번호부를 가져오는 함수 
		Cursor cursor = cx.getContentResolver()
				.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null
						, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);

		// 총 갯수를 알려줌 
		int end = cursor.getCount();
		Comm.LOG("end : " + end);		

		// 이름을 얻기 위한 변수 
		//		String[] name = new String[end];
		// 폰 넘버를 얻기 위한 변수 
		//		String[] phoneNumber  = new String[end];

		ArrayList<DBFriendItem> userItems = new ArrayList<DBFriendItem>();
		int count = 0;

		jArray = new JSONArray();

		if (cursor.moveToFirst()) {
			// 칼럼명으로 인덱스 찾기 
			int idIndex  = cursor.getColumnIndex(Phone._ID);
			int nameIndex = cursor.getColumnIndex(Phone.DISPLAY_NAME);
			int phoneIndex = cursor.getColumnIndex(Phone.NUMBER);

			// 요소값 얻기 
			do {
				// FriendItem에 넣는 방법이고!
				//				DBFriendItem item = new DBFriendItem();
				//				int id = cursor.getInt(idIndex); // id Index 얻기 
				//				item.setUserName(cursor.getString(nameIndex));
				//				item.setUserTel(cursor.getString(phoneIndex));

				// Id 와 성명과 전화번호를 가져온다.
				//				userItems.add(item);

				try {		
					jObject = new JSONObject();

					jObject.put("id", cursor.getInt(idIndex));
					jObject.put("userName", cursor.getString(nameIndex));
					jObject.put("phone", cursor.getString(phoneIndex));

					jArray.put(jObject);

				} catch (JSONException e) {
					Comm.LOG("JSON Error :" + e);
				}

				count++;
			} while(cursor.moveToNext() || count > end); // end while
		} // end if

		Comm.LOG(jArray + "");
		
		new SynchronizationFrinendThread(jArray.toString(), cx).start();
	}

	public class SynchronizationFrinendThread extends Thread {
		// 데이터 보내기 하면 됨!
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/MainControl.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;
		String userTel = null;
		Context cx = null;
		// 친구 정보를 다 가져왔다.

		List<NameValuePair> nValue = new ArrayList<NameValuePair>();

		BufferedReader br = null;
		StringBuilder sb = null;
		String line = "";

		public SynchronizationFrinendThread(String userTel, Context cx) {
			this.userTel = userTel;
			this.cx = cx;
		}

		//스레드 본체
		@Override
		public void run() {
			try {
				allTable = new ArrayList<AllTable>();
				client = NetManager.getHttpClient();
				reqeust = NetManager.getPost(webUrl);

				// 자신의 전화번호부를 채워서 보내야지! 
				nValue.add(new BasicNameValuePair("userTel", userTel));
				nValue.add(new BasicNameValuePair("event", "SynchronizationFriend"));
				
				// 내 아이디를 항상 보내준다 갱신할 때 
				// JSP에서는 이 userId가 Bad면 로그인을 하라고 하는데
				/**로그인을 할 때 이아이디를 다시 넣어줄 수 있도록 만들어야 할 것 같다.!!*/
				sp = cx.getSharedPreferences("loginId", 0);
				String spUserId = sp.getString("userId", "bad");
				
				nValue.add(new BasicNameValuePair("userId", spUserId));
				
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nValue, "utf-8");
				reqeust.setEntity(entity);

				response = client.execute(reqeust);
				Comm.LOG("SynchronizationFriend Thread Run()");
				code = response.getStatusLine().getStatusCode();

				Comm.LOG("code : " + code);
				switch(code) {
				case 200:
					br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
					sb = new StringBuilder();

					while((line = br.readLine()) != null) {
						sb.append(line + "\n");
					}
					
					// 이건 데이터베이스에서 내 친구라고 생각되는 사람들 가져온 것
					// SQLite를 통해서 데이터를 내부에 입력한 뒤 
					// SQLite를 통해서 뿌려주면 될 듯 

					friendAllInfo = JSONParser.getFriendAllInfo(sb.toString());
					Comm.LOG("친구목록 받아온 JSONArray : " + sb.toString());
					Comm.LOG("파싱이 빠른가?");
					
					if (friendAllInfo != null) {
//						 최초 테이블을 생성한 
						SharedPreferences sp1 = cx.getSharedPreferences("joinFIrst", 0);
						boolean init = sp1.getBoolean("init", true);
						
						if(init) { // 처음에는 갑을 다 넣을꺼고!
							// 현재는 JoinActivity에서 여기를 호출한거고 이 뒤로부터는 Setting Fragment
							// 에서 동기화를 호출할 것이야!
							// 처음 실행하는건 DoorOpenFragment로 값을 보내는거고
							// 그 뒤로부턴 세팅에 갱신부분만 선택하면 돼!
							// 파싱한 친구목록을 DoorOpenFragment로 넣어 놓았따.
							DoorOpenFragment.setFriendAllInfo(friendAllInfo);
							SharedPreferences.Editor editor = sp1.edit();
							editor.putBoolean("init", false);
							editor.commit();
						} else { // 다음부터는 갱신만 하자.
							// 이건 이제 SettingFragment로 가면 된다.
							SettingFragment.setFriendAllInfo(friendAllInfo);
						} // end if init
					} else 
						Comm.LOG("데이터가 null 이므로 SQLite Table 생성안됨 ");// end if friendAllTable
					break;
				}
			} catch (Exception e) {
				Comm.LOG("post 전송중 에러! : " + e.getMessage());
			}
		}// end run()
	} // end Thread

	// 이건 테스트 용이였어!
	class sendJsp extends Thread {
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/test.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;
		String arduinoMsg = null;

		List<NameValuePair> nValue = new ArrayList<NameValuePair>();

		BufferedReader br = null;
		StringBuilder sb = null;
		String line = "";

		public sendJsp(String arduinoMsg) {
			this.arduinoMsg = arduinoMsg;
		}

		//스레드 본체
		@Override
		public void run() {
			try {
				allTable = new ArrayList<AllTable>();
				client = NetManager.getHttpClient();
				reqeust = NetManager.getPost(webUrl);

				// 자신의 MAC주소를 채워서 보내야지! 
				getList(arduinoMsg);
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nValue, "utf-8");
				reqeust.setEntity(entity);

				response = client.execute(reqeust);
				Comm.LOG("sendJSP Thread Run()");
				code = response.getStatusLine().getStatusCode();

				Comm.LOG("code : " + code);
				switch(code) {
				case 200:
					br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
					sb = new StringBuilder();

					while((line = br.readLine()) != null) {
						sb.append(line + "\n");
					}

					// {} 이렇게 된 모든 값을 가져온 뒤 파싱으로 처리한다. 
					allTable = JSONParser.getAllTableParser(sb.toString());
					Comm.LOG("파싱 성공! AllTable : " + allTable);

					break;
				}
			} catch (Exception e) {
				Comm.LOG("post 전송중 에러! : " + e.getMessage());
			}
		}// end run()

		public void getList(String arduinoMsg) {
			String macAddress = "";
			String msg = null; // 아두이노의 디바이스 컬럼 가져오기 

			if(bt == null) 
				bt = new CKBluetooth();

			/* MAC Address 출력 */
			int i = 0;
			Set<BluetoothDevice> pairedDevices = bt.doReturnAdapter()
					.getBondedDevices();
			if (pairedDevices.size() > 0) {
				for (BluetoothDevice device : pairedDevices) {
					macAddress = device.getAddress();
					// 개인의 MAC Address니까 서버에 등록해버리면 돼!
				}
			}

			/* MAC Address 출력 끝 !! */
			nValue.add(new BasicNameValuePair("deviceId", msg));
			nValue.add(new BasicNameValuePair("userMac", macAddress));		
		}
	} // end Thread
}
