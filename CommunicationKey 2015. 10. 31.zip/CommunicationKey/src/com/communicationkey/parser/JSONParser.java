package com.communicationkey.parser;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import com.communicationkey.debug.Comm;
import com.communicationkey.item.AllTable;
import com.communicationkey.item.DeviceItem;

public class JSONParser {
	
	public static ArrayList<DeviceItem> getMyDevice(String jsonString) {
		JSONObject jObject = null;
		JSONArray jArray = null;
		ArrayList<DeviceItem> deviceItems = null;
		DeviceItem deviceItem = null;
		
		try {
			jArray = new JSONArray(jsonString);
			
			deviceItems = new ArrayList<DeviceItem>();
			JSONObject friendTemp = null;
			
			for(int i = 0; i < jArray.length(); i++) {
				deviceItem = new DeviceItem(); 
				friendTemp = jArray.getJSONObject(i);
				
				deviceItem.setDeviceId(friendTemp.getString("deviceId"));
				
				deviceItems.add(deviceItem);
			}
			
		} catch (Exception e) {
			Comm.LOG("JSONParser Error : " + e);
			return null;
		}
		return deviceItems;
	}
	
		// 안드로이드에서 전화번호를 JSP로 전달하고, JSP에서 디비로 ALLTAble로 조회를 한다.
	// 조회한 데이터를 기반으로 FriendTable에 나랑 친구를 적어놓고 
	// 조회한 데이터를 기반으로 AllTable에서 친구를 찾아서 가져오는 파싱
	public static ArrayList<AllTable> getFriendAllInfo(String jsonString) {
		JSONObject jObject = null;
		JSONArray jArray = null;
		ArrayList<AllTable> friendAllInfo = null;
		AllTable allTable = null;
		
		try {
			jArray = new JSONArray(jsonString);
			
			friendAllInfo = new ArrayList<AllTable>();
			JSONObject friendTemp = null;
			
			for(int i = 0; i < jArray.length(); i++) {
				allTable = new AllTable(); 
				friendTemp = jArray.getJSONObject(i);
				
				allTable.setUserId(friendTemp.getString("userId"));
				allTable.setUserName(friendTemp.getString("userName"));
				allTable.setUserTel(friendTemp.getString("userTel"));
				allTable.setUserMac(friendTemp.getString("userMac"));
				
				friendAllInfo.add(allTable);
			}
			
		} catch (Exception e) {
			Comm.LOG("JSONParser Error : " + e);
			return null;
		}
		
		return friendAllInfo;
	}
	
	// 회원가입을 하기 전에 아이디 중복확인을 해야 하는데 중복일 경우는 doNo를 리턴하고
	// 아이디가 중복되지 않을 떄 doOk를 리턴한다.
	public static String getCheckIdParser(String jsonString) {
		JSONObject jObject = null;
		String result = "";
		
		try {
			jObject = new JSONObject(jsonString);
			result = jObject.getString("result");
			
		} catch (Exception e) {
			Comm.LOG("JSONParser Error : " + e);
		}
		return result;
	}
	
	// DB Device Table에서 정보를 검색해서 있으면 doOpen 이라는 값을 리턴해주는데 그걸 파싱하는 것
	// 일치하는 Data가 없을 경우 doNotOpen을 리턴
	public static String getDeviceTableParser(String jsonString) {
		JSONObject jObject = null;
		String result = "";
		
		try {
			jObject = new JSONObject(jsonString);
			result = jObject.getString("result");
			
		} catch (Exception e) {
			Comm.LOG("JSONParser Error : " + e);
		}
		return result;
	}
	
	// 초기 파싱 테스트용이였어!
	public static ArrayList<AllTable> getAllTableParser(String jsonString) {
		JSONObject jObject = null;
		JSONArray jArrayAllTable = null;
		ArrayList<AllTable> allTables = null;
		AllTable allTable = null;
		
		try {
			jObject = new JSONObject(jsonString);
			jArrayAllTable = jObject.getJSONArray("allTable");
			
			allTables = new ArrayList<AllTable>();
			JSONObject allTableTemp = null;
			
			for(int i = 0; i < jArrayAllTable.length(); i++) {
				allTable = new AllTable(); 
				allTableTemp = jArrayAllTable.getJSONObject(i);
				Comm.LOG(allTableTemp + "");
				
				allTable.setUserId(allTableTemp.getString("userId"));
				allTable.setUserPw(allTableTemp.getString("userPw"));
				allTable.setUserName(allTableTemp.getString("userName"));
				allTable.setUserTel(allTableTemp.getString("userTel"));
				allTable.setUserMac(allTableTemp.getString("userId"));
				
				allTables.add(allTable);
			}
			
		} catch (Exception e) {
			Comm.LOG("JSONParser Error : " + e);
		}
		
		return allTables;
	}
}
