package com.communicationkey.debug;

import java.io.BufferedReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;

public class OracleDB {

	public static void dbConnect() {
		String webUrl = "http://61.105.185.71:8088/GoniTest/GoniSuccess/DeviceTable.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;
		
		String arduinoMsg = null; // 아두이노의 기기값을 저장하는 스트링 
		boolean open = false; // true면 문 열어주는 함수 사용 false면 실패 
		BufferedReader br = null; // 객체를 받아오기 위함
		StringBuilder sb = null; // 받아온 데이터를 축척하기 위함 
		String line = ""; // br의 값을 한개씩 저장해서 sb에 축척함 
		
		
	}
}
