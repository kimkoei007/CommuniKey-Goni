package com.communicationkey.debug;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class Comm {
	public static final String TAG = "Goni";
	public static final boolean L = true;
	public static final boolean T = true;

	public static final void LOG(String memo) {
		if (L)
			Log.v(TAG, memo);
	}

	public static final void TOAST(Context cx, String memo) {
		if (T)
			Toast.makeText(cx, memo, Toast.LENGTH_SHORT).show();
	}
}
