package com.communicationkey.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.communicationkey.debug.Comm;
import com.communicationkey.item.SettingItem;
import com.example.communicationkey.R;

public class SettingListViewAdapter extends BaseAdapter {

	Context context;
	int layout;
	ArrayList<SettingItem> data; // 아래 함수에서 쓰기 위해서 맴버변수를 접근 가능하게 하기 위해

	public SettingListViewAdapter(Context context, int layout, ArrayList<SettingItem> data) {
		this.context = context;
		this.layout = layout;
		this.data = data;
		// 초기작업은 여기서 생성자는 1번만 돌아갈테니까.
	}

	@Override
	public int getCount() {
		// 화면에 전체로 출력 된다. 100개면 100개 1000개면 1000개
				// ArrayList 개수만큼 보여주면 된다
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public Object getItem(int position) {// 현재 선택된 위치에서 반환 받을 위치
		
		// TODO Auto-generated method stub
		return data.get(position);// 반환타입이 Object니까 받는 쪽에서 형변환 해서 받아야 해
	}

	@Override
	public long getItemId(int position) {
		 // 아이템을 구분을 하기 위한 것
		// TODO Auto-generated method stub
		return position;
	}
	
	class viewHolder {
		TextView tvSettingItem;

	}

	@Override
	public View getView(int position, View cView, ViewGroup parent) {
		// 이대로 고쳐야 돼!
		final SettingItem item = data.get(position);
		viewHolder holder = null;
		
		if(cView == null) {
			cView = View.inflate(context, layout, null);
			holder = new viewHolder();
			holder.tvSettingItem = (TextView)cView.findViewById(R.id.tvSettingItem);
			
			cView.setTag(holder);
		} else {
			holder = (viewHolder)cView.getTag();
		}
		holder.tvSettingItem.setText(item.getSettingTitle());
		return cView;
	}
}
