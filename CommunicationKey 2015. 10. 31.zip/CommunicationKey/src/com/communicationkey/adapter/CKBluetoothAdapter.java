package com.communicationkey.adapter;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.communicationkey.bluetooth.CKBluetoothItem;
import com.communicationkey.debug.Comm;
import com.example.communicationkey.R;

public class CKBluetoothAdapter extends BaseAdapter {
	
	Activity context;
	int layout;
	ArrayList<CKBluetoothItem> data = null;
	
	public CKBluetoothAdapter(Activity context, int layout, ArrayList<CKBluetoothItem> data){
		this.context = context;
		this.layout = layout;
		this.data = data;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	
	class viewHolder {
		TextView tvBluetoothItem1, tvBluetoothItem2;
	}

	@Override
	public View getView(int position, View cView, ViewGroup parent) {
		viewHolder holder = null;
		if(cView == null){
			holder = new viewHolder();
			
			cView = View.inflate(context, layout, null);
			holder.tvBluetoothItem1 = (TextView)cView.findViewById(R.id.tvBluetoothItem1);
			holder.tvBluetoothItem2 = (TextView)cView.findViewById(R.id.tvBluetoothItem2);		
			
			cView.setTag(holder);
		} else {
			holder = (viewHolder) cView.getTag();
		}
		
		final CKBluetoothItem item = data.get(position);
		
		holder.tvBluetoothItem1.setText(item.getName());
		holder.tvBluetoothItem2.setText(item.getAddress());	
		
		return cView;
	}

}
