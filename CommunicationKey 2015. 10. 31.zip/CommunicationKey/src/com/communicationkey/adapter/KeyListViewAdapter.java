package com.communicationkey.adapter;

import java.util.ArrayList;

import com.communicationkey.item.KeyListItem;
import com.example.communicationkey.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class KeyListViewAdapter extends BaseAdapter {

	Context context;
	int layout;
	ArrayList<KeyListItem> data;

	public KeyListViewAdapter(Context contexxt, int layout,
			ArrayList<KeyListItem> data) {
		this.context = contexxt;
		this.layout = layout;
		this.data = data;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	class viewHolder {
		ImageView keyImage;
		TextView keyPeriod;
		TextView keyExpiration;
	}

	@Override
	public View getView(int position, View cView, ViewGroup parent) {
		final KeyListItem item = data.get(position);
		viewHolder holder = null;
		
		if ( cView == null ) {
			cView = View.inflate(context, layout, null);
			holder = new viewHolder();
			
			holder.keyImage = (ImageView)cView.findViewById(R.id.ivImage);
			holder.keyPeriod = (TextView)cView.findViewById(R.id.tvName);
//			holder.keyExpiration = (TextView)cView.findViewById(R.id.tvResidence);
			
			cView.setTag(holder);
		} else {
			holder = (viewHolder)cView.getTag();
		}
		
		holder.keyImage.setImageResource(item.getKeyImage());
		holder.keyPeriod.setText(item.getKeyPeriod());
		holder.keyExpiration.setText(item.getKeyExpiration());
		return cView;
	}

}
