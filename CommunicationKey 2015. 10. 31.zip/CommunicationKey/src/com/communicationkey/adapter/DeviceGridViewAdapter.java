package com.communicationkey.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

import com.communicationkey.debug.Comm;
import com.communicationkey.item.DeviceItem;
import com.communicationkey.main.KeyTransmissionActivity;
import com.example.communicationkey.R;

public class DeviceGridViewAdapter extends BaseAdapter{
	
	Context context;
	int layout;
	ArrayList<DeviceItem> data;
	boolean onChecked = false;
	
	public DeviceGridViewAdapter(Context context, int layout, ArrayList<DeviceItem> data) {
		this.context = context;
		this.layout = layout;
		this.data = data;
		Comm.LOG("DeviceGridViewAdapter : " + this.data.toString());
	}

	@Override
	public int getCount() {
		// 화면에 전체로 출력 된다. 100개면 100개 1000개면 1000개
				// ArrayList 개수만큼 보여주면 된다
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public Object getItem(int position) {// 현재 선택된 위치에서 반환 받을 위치
		
		// TODO Auto-generated method stub
		return data.get(position);// 반환타입이 Object니까 받는 쪽에서 형변환 해서 받아야 해
	}

	@Override
	public long getItemId(int position) {
		 // 아이템을 구분을 하기 위한 것
		// TODO Auto-generated method stub
		return position;
	}
	
	class viewHolder {
		TextView tvDeviceId;
		CheckBox cbDeviceId;
	}

	@Override
	public View getView(int position, View cView, ViewGroup parent) {
		// 이대로 고쳐야 돼!
		final DeviceItem item = data.get(position);
		viewHolder holder = null;
				
		if(cView == null) {
			cView = View.inflate(context, layout, null);
			holder = new viewHolder();
			holder.tvDeviceId = (TextView) cView.findViewById(R.id.tvDeviceId);
			holder.cbDeviceId = (CheckBox) cView.findViewById(R.id.cbDeviceId);
			
			cView.setTag(holder);
		} else {
			holder = (viewHolder)cView.getTag();
		}

		holder.tvDeviceId.setText(item.getDeviceId());
		holder.cbDeviceId.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// 체크가 되있으면 또 체크되게 하면 안되잖아! 이거 나중에 구현 하도록 함
				if(isChecked) {
					KeyTransmissionActivity.setDeviceId(item.getDeviceId());
				} else {
					KeyTransmissionActivity.setDeviceId(null);
				}
			}
		});
		return cView;
	}
}
