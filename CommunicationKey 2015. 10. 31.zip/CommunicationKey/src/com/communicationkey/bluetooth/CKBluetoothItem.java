package com.communicationkey.bluetooth;

import java.io.Serializable;

public class CKBluetoothItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3972090089491398963L;

	private String address;
	private String name;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "CKBluetoothItem [address=" + address + ", name=" + name + "]";
	}
	
	

}
