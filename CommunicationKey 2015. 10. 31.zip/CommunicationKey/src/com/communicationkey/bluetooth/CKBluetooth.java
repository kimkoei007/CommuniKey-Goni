package com.communicationkey.bluetooth;

import com.communicationkey.debug.Comm;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.util.Log;

public class CKBluetooth {
	BluetoothAdapter adapter = null;
	BluetoothServerSocket bss = null;
	BluetoothDevice device = null;
	BluetoothSocket bs = null;

	// 1번 생성자 초기화를 해서 adapter를 만들자.
	public CKBluetooth() { 
		adapter = BluetoothAdapter.getDefaultAdapter();
	}

	// 2번 블루투스를 지원하는 장비이냐? 블루투스가 없으면 널이뜬다.
	public boolean doStart() {
		if (adapter != null) {
			return true;
		} else {
			return false;
		}
	}

	// 3번 블루투스 켜졌니? 꺼져있으면 키자
	public boolean doEnable() {
		if (adapter.isEnabled()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean doScan() {
		if (adapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
			return true;
		} else {
			return false;
		}
	}

	// 디바이스를 얻어온다.
	public BluetoothDevice getDevice(String address) {
		device = adapter.getRemoteDevice(address);
		return device;
	}

	// 디바이스를 통해 블루투스 소켓을 생성한다.
	public BluetoothSocket createDevice() {
		try {
			bs = device
					.createRfcommSocketToServiceRecord(CKBlueService.MY_UUID_BLUETOOTH);
		} catch (Exception e) {
			Comm.LOG("CKBluetooth createDevice() error : " + e);
		}
		Comm.LOG("CKBluetooth createDevice() bs : " + bs);
		return bs;
	}

	// 블루투스 어댑터를 반환해준다.
	public BluetoothAdapter doReturnAdapter() { // 어뎁터를 리턴하기 위한 함수
		return adapter;
	}

	public void doCancelDiscovery() {
		adapter.cancelDiscovery();
	}

	public boolean doDiscovering() { // 검색중이면 중지하고 검색하고! 아니면 그대로 그냥 검색!
		if (adapter.isDiscovering()) {
			return true;
		} else {
			return false;
		}
	}

	public BluetoothServerSocket doCreateSocket() { // Server가 소켓을 생성해서 기다려!
		try {
			bss = adapter.listenUsingRfcommWithServiceRecord("server",
					CKBlueService.MY_UUID_SECURE);
		} catch (Exception e) {
		}
		return bss;

	}

	// 블루투스 검색 함수!
	public void doDiscovery() {
		if (adapter.isDiscovering()) {
			adapter.cancelDiscovery();
		}
		adapter.startDiscovery();
	}

}
