package com.communicationkey.fragment;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.communicationkey.bluetooth.CKBluetooth;
import com.communicationkey.bluetooth.CKBluetoothItem;
import com.communicationkey.debug.Comm;
import com.communicationkey.helper.FriendHelper;
import com.communicationkey.item.AllTable;
import com.communicationkey.main.DeviceListActivity;
import com.communicationkey.main.JoinActivity;
import com.communicationkey.service.BluetoothConnectService;
import com.example.communicationkey.R;

public class DoorOpenFragment extends Fragment {

	public Activity activity; // Main을 컨트롤 하기 위함
	public ImageView ivDoorOpen;
	public CKBluetoothItem item = null;
	public static BluetoothSocket bs;
	final int LOGININTENT = 100; // LoginActivity 띄울 때 보낼 상수
	public static ArrayList<AllTable> friendAllInfo = new ArrayList<AllTable>();
	
	// 블루투스 함수 모아둔 클래스.
	public CKBluetooth bt = null;
	public String remoteName = "temp"; // 연결 이름 알아내기
	// 블루투스가 사용 가능하면 서비스를 만들기 위해서 사용!
	public BluetoothConnectService cService = null;
	
	final int BT_ENABLED = 1; // 블루투스 지원 가능하니?
	final int REQUEST_ENABLE_BT = 2; // 블루투스 연결 되어있니?
	// DeviceListActivity.class에 requestCode
	private static final int REQUEST_CONNECT_DEVICE = 3;
	
	// DB를 열기 위함
	public FriendHelper helper = null;
	public SQLiteDatabase db = null;
	
	View.OnClickListener iHandler = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.btnDoorOepn:
				// 블루투스 장비 검색 
				Intent dIntent = new Intent(activity, DeviceListActivity.class);
				startActivityForResult(dIntent, REQUEST_CONNECT_DEVICE);
				break;
			case R.id.ivDoorOpen:
				// 아두이노로 데이터를 보내서 접속하는 방법 ( 문 열기 버튼 )
				String data = "a";
				
//				byte[] buffer = new byte[1];
//
//                buffer[0] = (byte) data.charAt(0);
//                cService.write(buffer);
				
                // 아두이노에서 받을 때 자꾸 ㅁㅁㅁㅁ이렇게 떠서 위에 조용희 교수님거 참고 함 
				byte[] send = data.getBytes();
				cService.contextJoin(activity);
				cService.write(send);

				break;
			}
		}
	};

	//	public Object

	// 최초 한번만 등록!
	public void doFirst() {

		/* 오라클 선택 후 메인화면 */
		/**일단 회원가입은 주석으로 막아둘꺼야!*/
		Intent intent = new Intent(activity, JoinActivity.class);
		startActivityForResult(intent, LOGININTENT);

	}

	// 블루투스 초기세팅
	public void doSettingBluetooth() {
		bt = new CKBluetooth();

		// [[1번]] 블루투스를 지원하니?
		if (!bt.doStart()) { 
			Comm.TOAST(activity, "블루투스를 지원하는 않습니다.");
			activity.finish();
			return;
		}

		// [[2번]] 블루투스 켜졌니? 꺼져있으면 키자
		if (!bt.doEnable()) { // 액션 REQUEST_ENABLE_BT 
			// 첫번째 파라미터는 Intent, 두번째 파라미터는 데이터를 구분할 값(requestCode)
			// setResult(파라미터1, 파라미터2)
			// 첫번째 파라미터는 데이터를 구분할 구분자 값, 두번째 파라미터는 값을 실어놓은 Intent
			Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(intent, BT_ENABLED);
		} else {
			if( cService == null ) 
				// 서비스를 동작시켜라.
				setupChat();
		} // end if
	}
	
	// 블루투스가 실행중이면 미리 서비스를 작동시켜라.
	private void setupChat() {
		cService = new BluetoothConnectService(activity);
		// 서비스를 킬려면 여기서 startService를 해줘야 함 
	}
	
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		Comm.LOG("DoorOpenActivity onAcitivtyResult requestCode : " + requestCode); 
		
		switch(requestCode) {
		case BT_ENABLED:
			switch (resultCode) {
			case Activity.RESULT_CANCELED:
				Comm.LOG("블루투스 사용하지 않음");
				break;
			case Activity.RESULT_OK:
				Comm.LOG("블루투스 켜기 성공");
				break;
			}
			break;
		case REQUEST_ENABLE_BT:
			switch (resultCode) {
			case Activity.RESULT_OK:
				// 서비스를 동작시켜라.
				if (cService == null) 
					setupChat();
				break;
			default:
				Comm.TOAST(activity, "블루투스를 켜야 사용이 가능합니다.");
				activity.finish();
				break;
			}
			// 실제로 접속이 붙는거야 이때 Service로 디바이스 목록( Address )를 보내
		case REQUEST_CONNECT_DEVICE:
			switch(resultCode) {
			case Activity.RESULT_OK:
				// 장비의 Mac주소를 가져오기.
				String address = data.getStringExtra(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
				// 장비의 디바이스를 가져와서 서비스로 넘겨준다.
				BluetoothDevice device = bt.getDevice(address);
				cService.connect(device);
				break;
				// LoginActivity에서 온 값으로 블루투스 킬지 말지 정해
			}
			break;
		case LOGININTENT:
			switch (resultCode) {
			case Activity.RESULT_OK:
				// 쓰레드가 늦게 끝나는 걸 방지 함 
				// 여기를 민규네 소스를 보고 전에 SyncronizationThread가 끝나면 이게 실행되게 만들어야 하는구나!
				SystemClock.sleep(2000);
				Comm.LOG("DoorOpenFragment LOGININTENT resultCode");
				Comm.LOG("friendAllInfo : " + friendAllInfo);
				
				// 가입하고 한번만 실행되기 때문에, 여기서 최초로 테이블을 생성하는 곳이야!
				helper = new FriendHelper(activity, "friend.db", null, 1, friendAllInfo);
				openDB();
				closeDB();
				break;
			case Activity.RESULT_CANCELED:
				Comm.TOAST(activity, "등록을 하지 않으면 사용하실 수 없습니다.");
			}	
			break;
		}
	}
	
	public static void setFriendAllInfo(ArrayList<AllTable> info) {
		friendAllInfo = info;
	}
	
	public void openDB() {
		// db = helper.getReadableDatabase(); // 읽기전용 즉 select만 할 수 있다.
		db = helper.getWritableDatabase(); // 쓰기전용 select insert delete 등 다 할 수
											// 있다
	}// 닫힌거 또 닫거나 열린거 또 열면 Error!

	public void closeDB() {
		if (db != null) {
			if (db.isOpen()) {
				db.close();
			}
		}
	}// 닫힌거 또 닫거나 열린거 또 열면 Error!

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.dooropen_fragment_new, container,
				false);

		view.findViewById(R.id.btnDoorOepn).setOnClickListener(iHandler);
		view.findViewById(R.id.ivDoorOpen).setOnClickListener(iHandler);
		ivDoorOpen = (ImageView) view.findViewById(R.id.ivDoorOpen);

		bt = new CKBluetooth();
		
		// 블루투스 지원? 후 키자 
		doSettingBluetooth();

		// 위에를 실행하면 서비스가 이미 생성이 되어있기 때문에
		// 션이 설치 후 1번만 실행을 하고 싶을 때! // 여기서 서버에 MAC주소와 이름, Email주소를 받아오자!
		SharedPreferences sp = activity.getSharedPreferences("firstAction", 0);
		// 2번째 인자는 Default 값!

		boolean init = sp.getBoolean("init", true);
		if (init) 
			doFirst(); // 여기서 서버에 MAC주소와 이름, Email주소를 받아오자!
		
		// DB Table을 생성 함 
		Comm.LOG("DoorOpen onCreate()");

		return view;
	}
	
	public DoorOpenFragment (BluetoothConnectService cService) {
		this.cService = cService;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		this.activity = activity;
		Comm.LOG("DoorOpen Fragment onAttach()");
	}

	@Override
	public void onDetach() { // fragment 종료 시 생기는 함수
		if (activity != null) {
			activity = null;
		}
		Comm.LOG("DoorOpen Fragment Detach");
		super.onDetach();
	}
}

/* MAC Address 출력 */
//int i = 0;
//Set<BluetoothDevice> pairedDevices = bt.doReturnAdapter()
//		.getBondedDevices();
//if (pairedDevices.size() > 0) {
//	for (BluetoothDevice device : pairedDevices) {
//		macAddress = device.getAddress();
//		// 개인의 MAC Address니까 서버에 등록해버리면 돼!
//	}
//}
///* MAC Address 출력 끝 !! */
