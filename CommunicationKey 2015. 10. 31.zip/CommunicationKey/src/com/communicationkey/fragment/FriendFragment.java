package com.communicationkey.fragment;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.communicationkey.adapter.FriendListViewAdapter;
import com.communicationkey.debug.Comm;
import com.communicationkey.helper.FriendHelper;
import com.communicationkey.item.FriendItem;
import com.communicationkey.main.KeyTransmissionActivity;
import com.communicationkey.main.ProfileActivity;
import com.example.communicationkey.R;

public class FriendFragment extends Fragment {

	Activity activity; // Main을 컨트롤 하기 위함
	ListView list1;
	ArrayList<FriendItem> data = new ArrayList<FriendItem>();
	FriendListViewAdapter adapter = null;
	
	Cursor c;
	FriendHelper helper = null;
	SQLiteDatabase db = null;
	
	final int KEYTRANSMISSION = 300;
	
	OnItemClickListener lHandler = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int positon,
				long id) {
			String userName = data.get(positon).getFriendName();
			String userId = data.get(positon).getFriendId();
			String userMac = data.get(positon).getFriendMac();
			
			Intent intent = new Intent(activity, KeyTransmissionActivity.class);
			intent.putExtra("userName", userName);
			intent.putExtra("userId", userId);
			intent.putExtra("userMac", userMac);
			startActivityForResult(intent, KEYTRANSMISSION);
		}
	};
	
	class FriendThread extends Thread {
		public void run() {
			helper = new FriendHelper(activity, "friend.db", null, 1);
			db = helper.getReadableDatabase();
			
			c = db.query("friend", null, null, null, null, null, null);
			
			FriendItem object = null;
			data.clear();
			
			while(c.moveToNext()) {
				object = new FriendItem();
				object.setFriendId(c.getString(1));
				object.setFriendName(c.getString(2));
				object.setFriendTel(c.getString(3));
				object.setFriendMac(c.getString(4));
				
				data.add(object);
				// DB에 순서 4가지를 집어 넣었음.
//				userId = c.getString(1);
//				userName = c.getString(2);
//				userTel = c.getString(3);
//				userMac = c.getString(4);
			} // end while
			
			c.close();
			db.close();
			
			activity.runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Comm.LOG("FriendFragment : " + data);
					adapter.notifyDataSetChanged();
				}
			});
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.friend_fragment_new, null);
		
		Comm.LOG("Friend Fragment onCreate()");
		
		list1 = (ListView)view.findViewById(R.id.lvFriend);
		list1.setOnItemClickListener(lHandler);
		
		// SQLite에 접근해서 친구목록을 화면에 뿌려줄 준비를 한다. 
		new FriendThread().start();
		
		adapter = new FriendListViewAdapter(activity,
				R.layout.listview_item, data); // context, 한줄에 보여줘야 할 xml, 다룰 실
												// data
		list1.setAdapter(adapter);

		return view;
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		this.activity = activity;
		Comm.LOG("Friend Fragment onAttach()");
	}

	@Override
	public void onDetach() { // fragment 종료 시 생기는 함수
		if (activity != null) {
			activity = null;
		}
		Comm.LOG("Friend Fragment onDetach()");
		super.onDetach();
	}

}
