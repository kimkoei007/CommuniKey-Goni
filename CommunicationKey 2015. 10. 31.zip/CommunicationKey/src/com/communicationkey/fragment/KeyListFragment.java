package com.communicationkey.fragment;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.communicationkey.adapter.KeyListViewAdapter;
import com.communicationkey.bluetooth.CKBluetoothItem;
import com.communicationkey.debug.Comm;
import com.communicationkey.item.KeyListItem;
import com.example.communicationkey.R;

public class KeyListFragment extends Fragment {

	Activity activity; // Main을 컨트롤 하기 위함
	ListView list1;
	ArrayList<KeyListItem> data = new ArrayList<KeyListItem>();
	KeyListViewAdapter adapter = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.keylist_fragment_new, null);
		list1 = (ListView) view.findViewById(R.id.lvKeyList);

		// 1번째 Context, 2번째 한줄에 보여줘야 할 xml, 3번째 실 Data
		adapter = new KeyListViewAdapter(activity, R.layout.listview_item,
				data);

		list1.setAdapter(adapter);

		return view;
	}


	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		this.activity = activity;
		Comm.LOG("KeyList Fragment onAttach()");
	}

	@Override
	public void onDetach() { // fragment 종료 시 생기는 함수
		if (activity != null) {
			activity = null;
		}
		Comm.LOG("KeyList Fragment onDetach()");
		super.onDetach();
	}

}
