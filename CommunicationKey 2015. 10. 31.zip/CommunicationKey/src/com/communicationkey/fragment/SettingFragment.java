package com.communicationkey.fragment;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.communicationkey.adapter.SettingListViewAdapter;
import com.communicationkey.debug.Comm;
import com.communicationkey.helper.FriendHelper;
import com.communicationkey.item.AllTable;
import com.communicationkey.item.FriendItem;
import com.communicationkey.item.SettingItem;
import com.communicationkey.service.BluetoothConnectService;
import com.example.communicationkey.R;

public class SettingFragment extends Fragment {

	Activity activity; // Main을 컨트롤 하기 위함
	ListView list1;
	ArrayList<SettingItem> data = new ArrayList<SettingItem>();
	SettingListViewAdapter adapter;
	// 블루투스가 사용 가능하면 서비스를 만들기 위해서 사용!
	public BluetoothConnectService cService = null;
	
	SQLiteDatabase db = null;
	FriendHelper helper = null;
	
	public static ArrayList<AllTable> friendAllInfo = new ArrayList<AllTable>();

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.setting_fragment_new, null);
		list1 = (ListView)view.findViewById(R.id.lvSetting);
		
		if(cService == null) 
			cService = new BluetoothConnectService();
		
	// 친구목록 동기화 버튼!
		view.findViewById(R.id.btnSettingSynchronizationFriend).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				cService.synchronizationFriend(activity);
				SystemClock.sleep(2000);
				doInsertAll();
			}
		});
		
		// 테스트!! 친구목록이 잘 들어갔나 셀렉트 하는 것 
		 view.findViewById(R.id.btnSettingSychronizationFriendSelect).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				doSelecteAll();
			}
		});
		
		adapter = new SettingListViewAdapter(activity
				, R.layout.setting_listview_item_new, data);
		
		list1.setAdapter(adapter);

		return view;
	}
	
	public void doInsertAll() {
		
		if(helper == null)
			helper = new FriendHelper(activity, "friend.db", null, 1);
		
		openDB();

		try {

			for(int i = 0; i < friendAllInfo.size(); i++) {
				ContentValues values = new ContentValues();

				values.put("userId", friendAllInfo.get(i).getUserId());
				values.put("userName", friendAllInfo.get(i).getUserName());
				values.put("userTel", friendAllInfo.get(i).getUserTel());
				values.put("userMac", friendAllInfo.get(i).getUserMac());

				long id = db.insert("friend", null, values);

				if (id > 0)
					Comm.LOG("FriendHelper onCreate Insert Success");
				else 
					Comm.LOG("FriendHelper onCreate Insert Error!");
			}
		} catch (SQLException e) {
			Comm.LOG("SettingFragment friend.db insert Error : " + e);
		}

		closeDB();
	}
	
	public static void setFriendAllInfo (ArrayList<AllTable> info) {
		friendAllInfo = info;
	}
	
	void doSelecteAll() {

		if(helper == null)
			helper = new FriendHelper(activity, "friend.db", null, 1);
		
		openDB();

		Cursor c = null;
		// 반환Type 이 것을 이용하여 읽어 온다 또한 Cursor는 반환 해줘야 한다.
		try {
			// db.execSQL(sql);
			// 유일하게 select 문만 Cursor의 반환이 필요하기 때문에
			// execeSQl 을 쓸 수 없다. 이 것은 반환 Type이 존재하지 않기 때문이다.

			c = db.query("friend", null, null, null, null, null, "userName desc");
			// 1번째 Table 의 명 2번째는 반환 받고자 하는 컬럼을 쓰는 것 즉 select * from 중 *에 해당
			// 모든 컬럼을 받기 위해서는 null 쓰면 돼 3번째와 4번째는 조건절 안주고 싶으면 null 하면 돼
			// 5번째는 Groupby 6번째 Groupby 조건절인 Having 임 !
			// 7번째 정리하고 싶은 Column에 순(오름차순, 내림차순) asc = 오름차순 desc = 내림차순
			// ex) 이름을 오름차순 = "fName asc" 쓰면 돼
			String userId;
			String userName;
			String userTel;
			String userMac;

			while (c.moveToNext()) {
				userId = c.getString(1);
				userName = c.getString(2);
				userTel = c.getString(3);
				userMac = c.getString(4);
				// c.get데이터의 타입으로 불러 온다.
				Comm.LOG("userId : " + userId + "userName : " + userName + "userTel : " + userTel + "userMac : " + userMac);
			}
		} catch (SQLException e) {
			Comm.LOG("read Error : " + e);
		} finally {
			if (c != null) {
				c.close();
			}
		}
		closeDB();

		// 방법 1 SQL문을 사용하는 방법
		// String sql = "select * from member where bigo = 0;";
		// // SQL 관계 연산자는 = 다
		// Cursor c = null;
		// // 반환Type 이 것을 이용하여 읽어 온다 또한 Cursor는 반환 해줘야 한다.
		// try {
		// // db.execSQL(sql);
		// // 유일하게 select 문만 Cursor의 반환이 필요하기 때문에
		// // execeSQl 을 쓸 수 없다. 이 것은 반환 Type이 존재하지 않기 때문이다.
		//
		// c = db.rawQuery(sql, null);
		// String fName;
		// String lName;
		// int bigo;
		//
		// while( c.moveToNext() ) {
		// fName = c.getString(1);
		// lName = c.getString(2);
		// bigo = c.getInt(5);
		// // c.get데이터의 타입으로 불러 온다.
		// Log.v(TAG, fName + " " + lName + " " + bigo);
		// }
		// } catch(SQLException e) {
		// Log.v(TAG, "read Error : " + e);
		// } finally {
		// if( c!= null ) {
		// c.close();
		// }
		// }
		closeDB();
	}
	
	public void openDB() {
		// db = helper.getReadableDatabase(); // 읽기전용 즉 select만 할 수 있다.
		db = helper.getWritableDatabase(); // 쓰기전용 select insert delete 등 다 할 수
											// 있다
	}// 닫힌거 또 닫거나 열린거 또 열면 Error!

	public void closeDB() {
		if (db != null) {
			if (db.isOpen()) {
				db.close();
			}
		}
	}// 닫힌거 또 닫거나 열린거 또 열면 Error!

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		this.activity = activity;
		Comm.LOG("Setting Fragment onAttach()");
	}

	@Override
	public void onDetach() { // fragment 종료 시 생기는 함수
		if (activity != null) {
			activity = null;
		}
		Comm.LOG("Setting Fragment onDetach()");
		super.onDetach();
	}

}
