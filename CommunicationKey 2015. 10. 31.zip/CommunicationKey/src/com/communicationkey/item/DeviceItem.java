package com.communicationkey.item;

import java.io.Serializable;

public class DeviceItem implements Serializable {

	private static final long serialVersionUID = -4795414535564834901L;
	
	private String deviceId;
	
	public DeviceItem () {}  
	public DeviceItem (String text) {
		deviceId = text;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	@Override
	public String toString() {
		return "DeviceItem [deviceId=" + deviceId + "]";
	}

	
}
