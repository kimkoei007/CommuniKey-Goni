package com.communicationkey.item;

import java.io.Serializable;

public class FriendItem implements Serializable {
	// FriendFragment 의 Item List
	private static final long serialVersionUID = -5132374814139434205L;

	private String friendId;	// 서버와 통신할 ID!
	private int friendImage; // 프로필 사진
	private String friendName; // 친구의 Name (고정 값)
	private String friendTel; // 친구의 메모 (사용자가 변경할 수 있어)
	private String friendMac; // 친구의 맥주소.

	public FriendItem() {
		
	}
	
	public FriendItem(String friendId, int friendImage, String friendName,
			String friendTel, String friendMac) {
		this.friendId = friendId;
		this.friendImage = friendImage;
		this.friendName = friendName;
		this.friendTel = friendTel;
		this.friendMac = friendMac;
	}

	public String getFriendId() {
		return friendId;
	}

	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}

	public int getFriendImage() {
		return friendImage;
	}

	public void setFriendImage(int friendImage) {
		this.friendImage = friendImage;
	}

	public String getFriendName() {
		return friendName;
	}

	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}

	public String getFriendTel() {
		return friendTel;
	}

	public void setFriendTel(String friendTel) {
		this.friendTel = friendTel;
	}

	public String getFriendMac() {
		return friendMac;
	}

	public void setFriendMac(String friendMac) {
		this.friendMac = friendMac;
	}

	@Override
	public String toString() {
		return "FriendItem [friendId=" + friendId + ", friendImage="
				+ friendImage + ", friendName=" + friendName + ", friendTel="
				+ friendTel + ", friendMac=" + friendMac + "]";
	}

	
}
