package com.communicationkey.item;

import java.io.Serializable;

public class DBFriendItem implements Serializable {

	private static final long serialVersionUID = -3701341961152692479L;

	private String userId;
	private String userName;
	private String userTel;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserTel() {
		return userTel;
	}

	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}

	@Override
	public String toString() {
		return "UserItem [userId=" + userId + ", userName=" + userName
				+ ", userTel=" + userTel + "]";
	}

}
