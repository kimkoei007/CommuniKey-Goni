package com.communicationkey.item;

import java.io.Serializable;

public class SettingItem implements Serializable {

	private static final long serialVersionUID = -1233502164809650400L;

	private String settingTitle;
	
	public SettingItem(String settingTitle) {
		this.settingTitle = settingTitle;
	}

	public String getSettingTitle() {
		return settingTitle;
	}

	public void setSettingTitle(String settingTitle) {
		this.settingTitle = settingTitle;
	}

	@Override
	public String toString() {
		return "SettingItem [settingTitle=" + settingTitle + "]";
	}
	
	
}
