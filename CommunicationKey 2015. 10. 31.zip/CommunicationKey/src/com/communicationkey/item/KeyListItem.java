package com.communicationkey.item;

import java.io.Serializable;

public class KeyListItem implements Serializable {

	private static final long serialVersionUID = -8772521686500294045L;

	private int keyImage; // 프로필 사진
	private String keyPeriod; // 키의 기간 ( 고정 값 )
	private String keySource; // 키의 발신지 + 키를 보낸사람의 이름 ( 고정 값 )
	private String keyExpiration; // 키의 유효기간 표시 ( 고정 값 )

	public KeyListItem(int keyImage, String keyPeriod, String keySource,
			String keyExpiration) {
		this.keyImage = keyImage;
		this.keyPeriod = keyPeriod;
		this.keySource = keySource;
		this.keyExpiration = keyExpiration;
	}

	@Override
	public String toString() {
		return "KeyListItem [keyImage=" + keyImage + ", keyPeriod=" + keyPeriod
				+ ", keySource=" + keySource + ", keyExpiration="
				+ keyExpiration + "]";
	}

	public int getKeyImage() {
		return keyImage;
	}

	public void setKeyImage(int keyImage) {
		this.keyImage = keyImage;
	}

	public String getKeyPeriod() {
		return keyPeriod;
	}

	public void setKeyPeriod(String keyPeriod) {
		this.keyPeriod = keyPeriod;
	}

	public String getKeySource() {
		return keySource;
	}

	public void setKeySource(String keySource) {
		this.keySource = keySource;
	}

	public String getKeyExpiration() {
		return keyExpiration;
	}

	public void setKeyExpiration(String keyExpiration) {
		this.keyExpiration = keyExpiration;
	}

}
