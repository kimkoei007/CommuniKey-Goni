package com.communicationkey.main;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.communicationkey.bluetooth.CKBluetooth;
import com.communicationkey.debug.Comm;
import com.communicationkey.fragment.DoorOpenFragment;
import com.communicationkey.fragment.FriendFragment;
import com.communicationkey.fragment.KeyListFragment;
import com.communicationkey.fragment.SettingFragment;
import com.communicationkey.helper.FriendHelper;
import com.communicationkey.service.BluetoothConnectService;
import com.example.communicationkey.R;

public class MainActivity extends Activity {
	

	FragmentManager fManager = null; // 프래그먼트를 얻기 위해!
	FragmentTransaction transaction = null; // 이걸로 화면을 갱신해
	FriendFragment fFragment = null; // 친구 목록 창을 띄워줘야지 !
	KeyListFragment kFragment = null;
	DoorOpenFragment dFragment = null; // 도어락에서만 쓰일 듯
	SettingFragment sFragment = null; // 친구 목록 창을 띄워줘야지 !

	/* 블루투스 변수 */
	CKBluetooth bt;
	BluetoothServerSocket bss = null; // 소켓변수 여기서 대기!?
	BluetoothSocket bs = null; // 접속을 하거나 접속을 기다리는 변수야
	BluetoothAdapter adapter = null; // 블루투스 어뎁터! 이걸 통해 기기 네임을 얻을 수 있어.
	/* 블루투스 변수 끝 */
	
	BluetoothConnectService cService = null;

	//  ivList 제거 함 
	int[] nArray = { R.id.ivFriend,  R.id.ivDoorOpen, R.id.ivSetting }; 
	ImageView[] ivList = new ImageView[3];

	// 이미지 뷰 처리 이벤트
	View.OnClickListener iHandler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			ivInit(); // setSelected False를 해줌 
			transaction = fManager.beginTransaction();
			switch (v.getId()) {
			case R.id.ivFriend:
				ivList[0].setSelected(true);
				if (fFragment == null) {
					// Fragmnet에 Fragment를 받아
					fFragment = new FriendFragment();
					// 1번 전달인자에 2번으로 치환해
				}
				transaction.replace(R.id.flMain, fFragment);
				break;
//			case R.id.ivList:
//				if (kFragment == null)
//					kFragment = new KeyListFragment();
//				transaction.replace(R.id.flMain, kFragment);
//				break;
			case R.id.ivDoorOpen:
				ivList[1].setSelected(true);
				if (dFragment == null)
					dFragment = new DoorOpenFragment(cService);
				transaction.replace(R.id.flMain, dFragment);
				break;
			case R.id.ivSetting:
				ivList[2].setSelected(true);
				if (sFragment == null)
					sFragment = new SettingFragment();
				transaction.replace(R.id.flMain, sFragment);
				break;
			}
			// 바뀌는 Reolatce Method를 Stack에 쌓ㅇ하서 저장해놓고 취소버튼을 누르면
			// 방금했던 작업들을 하나씩 빼버리는 역할을 한다.
			// 맨 마지막으로 오면 (Stack을 다 써버리면) 취소버튼의 기능을 제대로 역할한다.
			// transaction.addToBackStack(null);

			transaction.commit(); // 이걸 빼먹으면 갱신이 안돼!
		}
	};
	
	public void ivInit() {
		for(int i = 0; i < ivList.length; i++) 
			ivList[i].setSelected(false);
	}

	// 처음 화면을 보여주려는
	public void doInitFragment() {
		cService = new BluetoothConnectService();
		fManager = getFragmentManager(); // 버젼 4 이상 !!! 에서 사용하는 것 진저 폰은 못써 이러면
		transaction = fManager.beginTransaction(); // 트랜잭션을 만들어 줌

		// 현재 Activity를 Fragment에 보여주는
		dFragment = new DoorOpenFragment(cService);
		// 1번째 ID, 2번ㅈ째 집어넣고 싶은 Fragment
		transaction.replace(R.id.flMain, dFragment);

		transaction.commit(); // 이걸 빼먹으면 안 돼!
	}

	@Override
	// 블루투스 onActivityResult 함수
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// requestCode는 구분자 값
		switch (requestCode) {
		
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_new);
		
		Comm.LOG("MainActivity onCreate()");

		for (int i = 0; i < ivList.length; i++) { // Fragment 전환할 수 있는 버튼 엮기
			ivList[i] = (ImageView)findViewById(nArray[i]);
			ivList[i].setOnClickListener(iHandler);
		}
		
		ivInit();
		ivList[1].setSelected(true);

		doInitFragment();
	}

	@Override
	protected void onResume() {
		super.onResume();
		Comm.LOG("MainActivity onResume");
	}
	
	@Override
	protected void onPause() {
		Comm.LOG("MainActivity onPause");
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		Comm.LOG("MainActivity onDestroy");
		
		if ( cService != null ) {
			cService.stop();
			cService = null;
		}
		super.onDestroy();
	}
	
	
}
