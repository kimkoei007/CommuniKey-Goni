package com.communicationkey.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.communicationkey.R;

public class ProfileActivity extends Activity {

	int[] btnArray = { R.id.btnKeyTransmission, R.id.btnTextModify };

	View.OnClickListener bHandler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.btnKeyTransmission:
				Intent intent = new Intent(ProfileActivity.this,
						KeyTransmissionActivity.class);
				startActivity(intent);
				finish();
				break;
			case R.id.btnTextModify:
				break;
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile_new);

		for (int id : btnArray) {
			findViewById(id).setOnClickListener(bHandler);
		}
	}

}
