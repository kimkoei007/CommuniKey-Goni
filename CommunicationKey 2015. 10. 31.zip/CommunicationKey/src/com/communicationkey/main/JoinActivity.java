package com.communicationkey.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.communicationkey.bluetooth.CKBluetooth;
import com.communicationkey.debug.Comm;
import com.communicationkey.fragment.NetManager;
import com.communicationkey.helper.FriendHelper;
import com.communicationkey.item.AllTable;
import com.communicationkey.parser.JSONParser;
import com.communicationkey.service.BluetoothConnectService;
import com.example.communicationkey.R;

public class JoinActivity extends Activity {

	TextView tvJoinId, tvJoinPass1, tvJoinPass2, tvJoinName1, tvJoinTel1;
	EditText etJoinId, etJoinPass1, etJoinPass2, etJoinName1, etJoinTel1;
	List<NameValuePair> nValue = null; // userId와 액션을 보내주기 위함!
	List<NameValuePair> allTable = null; // AllTable 정보를 보내주기 위함 
	Boolean checkId = false; // 아이디 버튼을 한번만 눌리게 하기 위함
	AllTable userInfo = null; // 회원가입된 유저의 Data를 서버에 올리기 위함 
	CKBluetooth bt = null;
	BluetoothConnectService cService = null;
	
	// database Table을 만들기 위함
	FriendHelper helper = null;
	
	// 야매로 쉐어드 프리퍼런스에 쓸 아이디를 임시로 담을 
	String spUserId = "";
	
	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case 100:
				// 아이디가 중복되지 않을 경우 
				Comm.TOAST(getApplicationContext(), "이 아이디를 사용하셔도 좋습니다.");
				break;
			case 200:
				// 아이디가 중복 될 경우 
				Comm.TOAST(getApplicationContext(), "이 아이디는 사용할 수 없습니다.");
				break;
			case 300:
				// 등록이 제대로 된 경우 
				Comm.TOAST(getApplicationContext(), "회원가입을 축하합니다.");
				setResult(RESULT_OK);
				Comm.LOG("JoinActivity RESULT_OK");
				finish();
				break;
			case 400:
				Comm.TOAST(getApplicationContext(), "서버에 등록되지 않았습니다.");
				break;
			}
		}
		
	};
	
	View.OnClickListener bHandler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()) {
			case R.id.btnJoinFindId:
				// 여기서 중복확인이 안되면 트루가 떨어지게 만들고 아래는 트루가 될 떄만 실행되게 만들어야 해 
				if(checkId == false) 
					checkUserId();
				else
					Comm.TOAST(getApplicationContext(), "아이디 중복확인이 완료되었습니다.");
				break;
			case R.id.btnJoinOK:
				if(checkId == true) 
					doSaveInfo();
				else 
					Comm.TOAST(getApplicationContext(), "아이디 중복확인을 먼저 해주세요.");
				break;
			case R.id.btnJoinReset:
				// 리셋버ㅡㄴ은 사용하지 않는다.
			}
		}
	};
	
	public void checkUserId() {
		if(nValue != null) { 
			nValue.clear();
		} else {
			nValue = new ArrayList<NameValuePair>();
		} // end if
		
		getCheckId(etJoinId.getText().toString());

		// 여기서 서버랑 붙어서 아이디 중복 체
		new checkUserIdThread(nValue).start();
	}
	
	public void getCheckId(String userId) {
		nValue.add(new BasicNameValuePair("userId", userId));
		nValue.add(new BasicNameValuePair("event", "checkUserId"));		
	}
	
	// 디비에서 userId가 중복되는지 확인할꺼야!
	public class checkUserIdThread extends Thread {
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/MainControl.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;

		BufferedReader br = null;
		StringBuilder sb = null;
		String line = "";

		List<NameValuePair> data = new ArrayList<NameValuePair>();

		public checkUserIdThread(List<NameValuePair> data) {
			this.data = data;
			Comm.LOG(data.toString());
		}

		//스레드 본체
		@Override
		public void run() {
			try {
				client = NetManager.getHttpClient();
				reqeust = NetManager.getPost(webUrl);
				Message msg = null;

				// data에는 userId와 액션이 들어가있어 검색해서 정보를 확인하려는거야!
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(data, "utf-8");
				reqeust.setEntity(entity);

				response = client.execute(reqeust);
				code = response.getStatusLine().getStatusCode();
				// 핸들러를 보내서 처리해볼까?

				Comm.LOG("code : " + code);
				switch(code) {
				case 200:
					br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
					sb = new StringBuilder();

					while((line = br.readLine()) != null) 
						sb.append(line + "\n");
					msg = handler.obtainMessage();

					// 파싱한 값을 받기 위함 
					String temp = JSONParser.getCheckIdParser(sb.toString());
					Comm.LOG("temp : " + temp);

					if(temp.equals("doOk")) {
						// 아이디가 중복되지 않을 경우 
						checkId = true;
						msg.what = 100;
					} else {
						// 아이디가 중복 될 경우 
						msg.what = 200;
					}
					handler.sendMessage(msg);
					break;
				}
			} catch (Exception e) {
				Comm.LOG("post 전송중 에러! : " + e.getMessage());
			}
		}// end run()
	} // end checkUserId Thread
		
	
	// 회원가입 정보를 서버로 보내야겠지!? 
	public void doSaveInfo() {
		if(userInfo != null)
			userInfo = null;
		
		if(allTable != null)
			allTable.clear();
		else
			allTable = new ArrayList<NameValuePair>();
		
		if(bt == null)
			bt = new CKBluetooth();
		
		String macAddress = null;
		userInfo = new AllTable();
		
		// 패스워드가 같아야 실행하고!
		if(etJoinPass1.getText().toString().equals(etJoinPass2.getText().toString())) {
			userInfo.setUserId(etJoinId.getText().toString());
			userInfo.setUserPw(etJoinPass2.getText().toString());
			userInfo.setUserName(etJoinName1.getText().toString());
			userInfo.setUserTel(etJoinTel1.getText().toString());
			
			/* MAC Address 출력 */
			int i = 0;
			Set<BluetoothDevice> pairedDevices = bt.doReturnAdapter()
					.getBondedDevices();
			if (pairedDevices.size() > 0) {
				for (BluetoothDevice device : pairedDevices) {
					macAddress = device.getAddress();
					// 개인의 MAC Address니까 서버에 등록해버리면 돼!
				}
			}
			/* MAC Address 출력 끝 !! */
			userInfo.setUserMac(macAddress);
			
			
			gerUserInfo(userInfo);
			
			new joinApp(allTable).start();
		} else {
			Comm.TOAST(getApplicationContext(), "비밀번호가 같지 않습니다.");
		}
	}
	
	public void gerUserInfo(AllTable userInfo) {
		allTable.add(new BasicNameValuePair("userId", userInfo.getUserId()));
		allTable.add(new BasicNameValuePair("userPw", userInfo.getUserPw()));
		allTable.add(new BasicNameValuePair("userName", userInfo.getUserName()));
		allTable.add(new BasicNameValuePair("userTel", userInfo.getUserTel()));
		allTable.add(new BasicNameValuePair("userMac", userInfo.getUserMac()));
		allTable.add(new BasicNameValuePair("event", "joinApp"));		
		spUserId = userInfo.getUserId();
	}
	
	// 아이디 중복 검사가 끝났으니 이제 Data를 서버에 올려볼까?
	public class joinApp extends Thread {
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/MainControl.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;

		BufferedReader br = null;
		StringBuilder sb = null;
		String line = "";

		List<NameValuePair> data = new ArrayList<NameValuePair>();

		public joinApp(List<NameValuePair> data) {
			this.data = data;
		}

		//스레드 본체
		@Override
		public void run() {
			try {
				client = NetManager.getHttpClient();
				reqeust = NetManager.getPost(webUrl);
				Message msg = null;

				// data에는 userId와 액션이 들어가있어 검색해서 정보를 확인하려는거야!
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(data, "utf-8");
				reqeust.setEntity(entity);

				response = client.execute(reqeust);
				code = response.getStatusLine().getStatusCode();
				// 핸들러를 보내서 처리해볼까?

				Comm.LOG("JoinAppThread code : " + code);
				switch(code) {
				case 200:
					br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
					sb = new StringBuilder();

					while((line = br.readLine()) != null) 
						sb.append(line + "\n");
					msg = handler.obtainMessage();

					// 파싱한 값을 받기 위함 
					String temp = JSONParser.getCheckIdParser(sb.toString());
					Comm.LOG("temp : " + temp);

					if(temp.equals("doOk")) {
						// 등록이 서버에 되었을 경우 
						msg.what = 300;

						/**자동 로그인 기능처럼 여기다 쉐어드프리퍼런스에 넣자.*/
						// 이러면 쉐어드프리퍼런스에 내 아이디가 등록이 된거야.
						
						SharedPreferences sp = getSharedPreferences("loginId", 0);
						SharedPreferences.Editor editor = sp.edit();
						editor.putString("userId", spUserId);
						editor.commit();
						
						// 서버에 등록이 되었으니까 갱신해야 겠네?
						if(cService == null)
							cService = new BluetoothConnectService();
						
						// 여기서 동기화된 첫 친구목륵의 리스트를 받아와서 ActivityForResult를 통해 !!
						// DoorOpen으로 전달하자.
						// 이게 호출되고 나면 핸드러를 통해서 JoinActivity가 꺼지게 된다.
						cService.synchronizationFriend(getApplicationContext());
						
					} else {
						// 서버에 등록이 실패하였을 경우 
						msg.what = 400;
					}
					handler.sendMessage(msg);
					break;
				}
			} catch (Exception e) {
				Comm.LOG("post 전송중 에러! : " + e.getMessage());
			}
		}// end run()
	} // end checkUserId Thread

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_join_new);
		
		Comm.LOG("JoinActivity onCreate");

		etJoinId = (EditText) findViewById(R.id.etJoinId);
		etJoinPass1 = (EditText) findViewById(R.id.etJoinPass1);
		etJoinPass2 = (EditText) findViewById(R.id.etJoinPass2);
		etJoinName1 = (EditText) findViewById(R.id.etJoinName1);
		etJoinTel1 = (EditText) findViewById(R.id.etJoinTel1);
		
		findViewById(R.id.btnJoinFindId).setOnClickListener(bHandler);
		findViewById(R.id.btnJoinOK).setOnClickListener(bHandler);
		findViewById(R.id.btnGoLogin).setOnClickListener(bHandler);
		
		// 지워 초기값 넣어줌
		etJoinId.setText("kimkoei006");

		// 1. AndroidManifest.xml 파일에 아래와 같은 권한 추가
		// <uses-permission android:name="android.permission.READ_PHONE_STATE"

		/** 공폰이라 전화번호가 없어서 일단 주석처리 해
		// 2. java 파일에 들어가는 소스
		// --내 폰의 전화번호 가져오기--
		TelephonyManager systemService = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		String PhoneNumber = systemService.getLine1Number();
		PhoneNumber = PhoneNumber.substring(PhoneNumber.length() - 10,
				PhoneNumber.length());
		PhoneNumber = "0" + PhoneNumber;

		// --얻어온 전화번호에 자동으로 하이픈(-) 추가--
		PhoneNumber = PhoneNumberUtils.formatNumber(PhoneNumber);
		// 하이픈이 찍히니까 이전에 어디에 저장해서 서버로 보내야 해 !

		// --원하는 에디트텍스트(여기서는 m_EditText_Phone)를 가져와서 setHint메소드로 디폴트값을 줌--
		etPhoneNumber.setHint(PhoneNumber);
		// --해당 에디트텍스트를 사용자입력 금지시킴--
		etPhoneNumber.setEnabled(false);
		*/

	}

}
