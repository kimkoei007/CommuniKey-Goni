package com.communicationkey.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.communicationkey.adapter.DeviceGridViewAdapter;
import com.communicationkey.bluetooth.CKBluetooth;
import com.communicationkey.debug.Comm;
import com.communicationkey.fragment.NetManager;
import com.communicationkey.item.DeviceItem;
import com.communicationkey.parser.JSONParser;
import com.example.communicationkey.R;

public class KeyTransmissionActivity extends Activity {
	static final int INIT = 0;	// 기간, 횟수 아무것도 선택되지 않은 값
	static final int NUMBER = 1;	// 횟수가 선택된 값 	// View.Visible
	static final int PERIOD = 2;	// 기간이 선택된 값 
	
	DatePicker datePicker;
	
	TextView tvUserName;  // 맨 위에 누구에게 보낼지 이름이 나타나게 됨 
	TextView tvYear, tvMonth, tvDay;	// 기간에 년, 월, 일 텍스트뷰 숨겨야지 !!
	CheckBox cbNumber, cbPeriod;
	Button btnKeyTransmission;
	Spinner spNumber, spYear, spMonth, spDay; // 기간, 횟수를 선택하는 스피너 선언 
	int nNumber, nYear, nMonth, nDay; // 기간을 설정할 때 세팅해줘야하는 
	ListView lvMyDevice;
	int nNumberVsPeriod = INIT;	// 이걸 통해서 Thread에서 분기해서 명령을 실행 함
	boolean bFirstSpinner = false; // 처음에 스피너가 자꾸 1번 실행되기 때문에 그걸 막기위한 변수 
	int nFirstSpinnerCount = 0; // 스피너를 엮으면 자꾸 그 엮은 수만큼 호출이 되기 때문에 그걸 막기위한 변수 
	DeviceGridViewAdapter adapter;
	ArrayAdapter aaNumberAdapter, aaYearAdapter, aaMonthAdapter, aaDayAdapter;
	
	CKBluetooth bt;
	
	private String userName = "";
	private String userId = "";
	private String userMac = "";
	private static String deviceId = null;
	
	private String myMac = "";
	
	ArrayList<DeviceItem> deviceItems = new ArrayList<DeviceItem>();
	
	// 스피너 리스너!
	OnItemSelectedListener sHandler = new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> parent, View view,
				int position, long id) {
			if (!bFirstSpinner) {
				nFirstSpinnerCount++;
				if(nFirstSpinnerCount == 4) {
					bFirstSpinner = true;
					
					// 넘버 초기화 
					nYear = 2015;
					nMonth = INIT;
					nDay = INIT;
					nNumber = 1;
				}
			} else {
				// 여기다가 소스를 작성해야 돼 ! 위에서는 한번 무조건 실행이 되서 문제가 되거든!

				switch(parent.getId()) {
				case R.id.spNumber:
					// 여길 들어왔으면 년 월 일을 초기화 해줘야 해
					nYear = 2015;
					nMonth = INIT;
					nDay = INIT;
					
					nNumber = Integer.parseInt((String) aaNumberAdapter.getItem(position));
					Comm.LOG("nNumber : " + nNumber);
									
					break;
				case R.id.spYear:
					nNumber = 1;
					
					nYear = Integer.parseInt((String) aaYearAdapter.getItem(position));
					Comm.LOG("nYear? : " + nYear);
					break;
				case R.id.spMonth:
					nNumber = 1;
					
					nMonth = Integer.parseInt((String) aaMonthAdapter.getItem(position));
					Comm.LOG("nYear? : " + nYear);
					break;
				case R.id.spDay:
					nNumber = 1;
					
					nDay = Integer.parseInt((String) aaDayAdapter.getItem(position));
					Comm.LOG("nYear? : " + nYear);
					break;
				}
 			}
		}

		@Override
		public void onNothingSelected(AdapterView<?> parent) {
			// TODO Auto-generated method stub
			
		}
	};
	// 체크박스 리스너 !
	OnCheckedChangeListener cHandler = new OnCheckedChangeListener() {
		
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			switch(buttonView.getId()) {
			case R.id.cbNumber:
				// 누를 때 여기 아래 if문이 호출 되니까 여기서 작업하면 될 듯????
				if(isChecked) {
					cbPeriod.setChecked(false); 
					
					// 횟수를 넣어줌.
					nNumberVsPeriod = NUMBER;
					
					// View.Visible
					spNumber.setVisibility(View.VISIBLE);
					
					// View.Invisible
					spYear.setVisibility(View.INVISIBLE);
					spMonth.setVisibility(View.INVISIBLE);
					spDay.setVisibility(View.INVISIBLE);
					tvYear.setVisibility(View.INVISIBLE);
					tvMonth.setVisibility(View.INVISIBLE);
					tvDay.setVisibility(View.INVISIBLE);
				} else {
					// 스피너가 보이고 있으면 안보이게 해주자.
					spNumber.setVisibility(View.INVISIBLE);
					nNumberVsPeriod = INIT;
				}
				break;
			case R.id.cbPeriod:
				if(isChecked) {
					cbNumber.setChecked(false); 
					
					// 기간을 넣어 
					nNumberVsPeriod = PERIOD;
					
					// View.Visible
					spYear.setVisibility(View.VISIBLE);
					spMonth.setVisibility(View.VISIBLE);
					spDay.setVisibility(View.VISIBLE);
					tvYear.setVisibility(View.VISIBLE);
					tvMonth.setVisibility(View.VISIBLE);
					tvDay.setVisibility(View.VISIBLE);
					
					// View.Invisible
					spNumber.setVisibility(View.INVISIBLE);
				} else {
					spYear.setVisibility(View.INVISIBLE);
					spMonth.setVisibility(View.INVISIBLE);
					spDay.setVisibility(View.INVISIBLE);
					tvYear.setVisibility(View.INVISIBLE);
					tvMonth.setVisibility(View.INVISIBLE);
					tvDay.setVisibility(View.INVISIBLE);
					nNumberVsPeriod = INIT;
				}
				break;
			}
		}
	};
	
	// 키를 보내기 전에 내가 등록된 디바이스 목록을 서버에서 받아와서 GridView로 보여줘야 하잖아!
	// 그래서 먼저 서버에 접속해서 리스트를 가져와서 ListView에 뿌려준다!
	public class SearchMyDeviceThread extends Thread {
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/MainControl.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;

		List<NameValuePair> nValue = new ArrayList<NameValuePair>();

		BufferedReader br = null;
		StringBuilder sb = null;
		String line = "";

		//스레드 본체
		@Override
		public void run() {
			try {
				client = NetManager.getHttpClient();
				reqeust = NetManager.getPost(webUrl);
				
				if(bt == null)
					bt = new CKBluetooth();
				
				/* MAC Address 출력 */
				int i = 0;
				Set<BluetoothDevice> pairedDevices = bt.doReturnAdapter()
						.getBondedDevices();
				if (pairedDevices.size() > 0) {
					for (BluetoothDevice device : pairedDevices) {
						myMac = device.getAddress();
						// 개인의 MAC Address니까 서버에 등록해버리면 돼!
					}
				}
				Comm.LOG("MyMac : " + myMac);
				/* MAC Address 출력 끝 !! */

				// 내 맥주소를 보내서 디바이스 테이블에 접근 후 내 등록된 기기를 보여줄 것임 
				nValue.add(new BasicNameValuePair("event", "searchMyDevice"));
				nValue.add(new BasicNameValuePair("userMac", myMac));
				
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nValue, "utf-8");
				reqeust.setEntity(entity);

				response = client.execute(reqeust);
				Comm.LOG("SearchMyDeviceThread Thread Run()");
				code = response.getStatusLine().getStatusCode();

				Comm.LOG("SearchMyDeviceThread code : " + code);
				switch(code) {
				case 200:
					br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
					sb = new StringBuilder();

					while((line = br.readLine()) != null) {
						sb.append(line + "\n");
					}
					
					ArrayList<DeviceItem> tempDeviceItems = new ArrayList<DeviceItem>();
					
					// 이렇게 템프에 넣고 직접 한개씩 adapter에 연결된 ArrayList에
					// add를 시켜줘야 한다. 직접 deviceItems에 파싱한 값을 넣으면
					// 연결이 해제되서인지 갱신이 되지 않으니 주의할 것 
					// deviceItems = JSONParser.getMyDevice(sb.toString());
					// 위와 같이 하면 값을 제대로 들어가지만 갱신이 되지 않는 상황을 볼 수 있다.
					
					tempDeviceItems = JSONParser.getMyDevice(sb.toString());
					
					for(int j = 0; j < tempDeviceItems.size(); j++) {
						DeviceItem temp = tempDeviceItems.get(j);
						deviceItems.add(temp);
					}

					Comm.LOG("DeviceItems : " + deviceItems);
					
					// 여기서 GridView에 디바이스 리스트를 띄워줄 것이야.
					runOnUiThread(new Runnable() {
						public void run() {
							adapter.notifyDataSetChanged();
						}
					});
					
					break;
				} // end switch
			} catch (Exception e) {
				Comm.LOG("SearchMyDeviceThread post 전송중 에러! : " + e.getMessage());
			}
		}// end run()
	} // end Thread
	
	public static void setDeviceId(String deviceId1) {
		deviceId = deviceId1;
	}
	
	class KeyTransmissionThread extends Thread {
		// 데이터 보내기 하면 됨!
		String webUrl = "http://210.219.160.83:8088/GoniTest/GoniSuccess/MainControl.jsp";
		int code = 0;
		HttpClient client = null;
		HttpPost reqeust = null;
		HttpResponse response = null;

		List<NameValuePair> nValue = new ArrayList<NameValuePair>();

		BufferedReader br = null;
		StringBuilder sb = null;
		String line = "";

		//스레드 본체
		@Override
		public void run() {
			try {
				if(!deviceId.equals(null)) {
					client = NetManager.getHttpClient();
					reqeust = NetManager.getPost(webUrl);
					
					runOnUiThread(new Runnable() {	
						@Override
						public void run() {
							Comm.TOAST(getApplicationContext(), deviceId + "의 Key 전송합니다.");
						}
					});

					// 체크된 디바이스 네임과 게스트의 맥과 게스트와 기간을 설정해 줘야 해 !
					nValue.add(new BasicNameValuePair("event", "keyTransmission"));
					nValue.add(new BasicNameValuePair("deviceId", deviceId));
					nValue.add(new BasicNameValuePair("userMac", userMac));
					nValue.add(new BasicNameValuePair("authority", "Guest"));
					
					// 이제 기간 or 횟수를 넘겨줘야 하는데 이걸 switch Case문으로 분기해서 넘겨줄 것이야!!
					switch(nNumberVsPeriod) {
					case INIT :
						runOnUiThread(new Runnable() {	
							@Override
							public void run() {
								Comm.TOAST(getApplicationContext(), "기간이나 횟수를 선택하세요.");
							}
						});
						Comm.LOG("nNumberVsPeriod : INIT");
						return;
					case NUMBER :
						Comm.LOG("nNumberVsPeriod : NUMBER");
						Comm.LOG("nNumber : " + nNumber);
						
						if(nNumber != 0)
							nValue.add(new BasicNameValuePair("period", nNumber + ""));
						else {
							runOnUiThread(new Runnable() {	
								@Override
								public void run() {
									Comm.TOAST(getApplicationContext(), "횟수를 선택하세요.");
								}
							});
						} // end if
						Comm.LOG("nValue : " + nValue.toString());
						break;
					case PERIOD :
						Comm.LOG("nNumberVsPeriod : PERIOD");
						Comm.LOG("nMonth : " + nMonth + "nDay : " + nDay);
						
						if(nMonth != 0 && nDay != 0)
							nValue.add(new BasicNameValuePair("period", nYear + "-" + nMonth + "-" + nDay));
						else {
							runOnUiThread(new Runnable() {	
								@Override
								public void run() {
									Comm.TOAST(getApplicationContext(), "년 / 월 / 일을 선택하세요.");
								}
							});
						}
								
						Comm.LOG("nValue : " + nValue.toString());
						break;
					}

					UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nValue, "utf-8");
					reqeust.setEntity(entity);

					response = client.execute(reqeust);
					Comm.LOG("KeyTransmissionThread Thread Run()");
					code = response.getStatusLine().getStatusCode();

					Comm.LOG("code : " + code);
					switch(code) {
					case 200:
						br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));
						sb = new StringBuilder();

						while((line = br.readLine()) != null) {
							sb.append(line + "\n");
						}
						break;
					} // end switch
				} // end if
				
			} catch (Exception e) {
				Comm.LOG("KeyTransmissionThread post 전송중 에러! : " + e.getMessage());
				
				runOnUiThread(new Runnable() {	
					@Override
					public void run() {
						Comm.TOAST(getApplicationContext(), "전달할 디바이스를 선택하세요.");
					}
				});
			}
		}// end run()
	} // end Thread

	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_keytransmission_new2);
		
		Comm.LOG("KeyTransmission Activity onCreate()");
		
		// FriendFragment에서 친구 데이터를 받아오는 중 !
		Intent intent = getIntent();
		userName = intent.getStringExtra("userName");
		userId = intent.getStringExtra("userId");
		userMac = intent.getStringExtra("userMac");

		tvUserName = (TextView)findViewById(R.id.tvUserName);
		tvYear = (TextView)findViewById(R.id.tvYear);
		tvMonth = (TextView)findViewById(R.id.tvMonth);
		tvDay = (TextView)findViewById(R.id.tvDay);
		
		// 제일 상단 라지텍스트에 보내려는 사람의 이름을 넣어 줌 
		tvUserName.setText(userName);
		
		lvMyDevice = (ListView) findViewById(R.id.lvMyDevice);
		
		// 이걸 가지고 누르면 옆에 스피너가 보이도록 하자.
		cbNumber = (CheckBox) findViewById(R.id.cbNumber);
		cbPeriod = (CheckBox) findViewById(R.id.cbPeriod);
		
		cbNumber.setOnCheckedChangeListener(cHandler);
		cbPeriod.setOnCheckedChangeListener(cHandler);
		
		spNumber = (Spinner) findViewById(R.id.spNumber);
		spYear = (Spinner) findViewById(R.id.spYear);
		spMonth = (Spinner) findViewById(R.id.spMonth);
		spDay = (Spinner) findViewById(R.id.spDay);
		
		// 스피너를 리스너에 엮자!
		spNumber.setOnItemSelectedListener(sHandler);
		spYear.setOnItemSelectedListener(sHandler);
		spMonth.setOnItemSelectedListener(sHandler);
		spDay.setOnItemSelectedListener(sHandler);
		
		aaNumberAdapter = ArrayAdapter.createFromResource(getApplicationContext(), 
				R.array.spiner_count, android.R.layout.simple_spinner_item);
		aaNumberAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spNumber.setAdapter(aaNumberAdapter);
		
		aaYearAdapter = ArrayAdapter.createFromResource(getApplicationContext(), 
				R.array.spiner_year, android.R.layout.simple_spinner_item);
		aaNumberAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spYear.setAdapter(aaYearAdapter);
		
		aaMonthAdapter = ArrayAdapter.createFromResource(getApplicationContext(), 
				R.array.spiner_month, android.R.layout.simple_spinner_item);
		aaNumberAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spMonth.setAdapter(aaMonthAdapter);
		
		aaDayAdapter = ArrayAdapter.createFromResource(getApplicationContext(), 
				R.array.spiner_day, android.R.layout.simple_spinner_item);
		aaNumberAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spDay.setAdapter(aaDayAdapter);
		
		// 처음에는 스피너가 보이지 말아야지.
		spNumber.setVisibility(View.INVISIBLE);
		spYear.setVisibility(View.INVISIBLE);
		spMonth.setVisibility(View.INVISIBLE);
		spDay.setVisibility(View.INVISIBLE);
		
		// 처음에는 년, 월, 일이 안보여야지 !!
		tvYear.setVisibility(View.INVISIBLE);
		tvMonth.setVisibility(View.INVISIBLE);
		tvDay.setVisibility(View.INVISIBLE);
		
		
		findViewById(R.id.btnKeyTransmission).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				new KeyTransmissionThread().start();
			}
		});

		// 선택한 날짜를 보여주게 하는 소스였어 ! 
//		datePicker = (DatePicker) findViewById(R.id.datePicker1);
//
//		datePicker.init(datePicker.getYear(), datePicker.getMonth(),
//				datePicker.getDayOfMonth(),
//				new DatePicker.OnDateChangedListener() {
//
//					@Override
//					public void onDateChanged(DatePicker view, int year,
//							int monthOfYear, int dayOfMonth) {
//						// TODO Auto-generated method stub
//						String msg = String.format("%d / %d / %d", year,
//								monthOfYear + 1, dayOfMonth);
//						
//						tvResultDate.setText(msg);
//				
//					}
//				});

		// 여기서 나의 MAC을 DeviceTable로 보내서 내가 등록되어있는 디바이스명을 가져온다.
		// 이걸 통해서 사용자들에게 뿌려줘야지.
		new SearchMyDeviceThread().start();
		
		adapter = new DeviceGridViewAdapter(getApplicationContext(), 
				R.layout.grid_device_item_new, deviceItems);
		
		lvMyDevice.setAdapter(adapter);
	}
}
