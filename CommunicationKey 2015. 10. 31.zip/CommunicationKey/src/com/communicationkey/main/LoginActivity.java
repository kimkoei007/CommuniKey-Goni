package com.communicationkey.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.communicationkey.R;

public class LoginActivity extends Activity {
	final int JOININTENT = 200;

	ImageView ivLoginButton, ivJoinButton, ivFindPassward;	// 로그인버튼과 회원가입과 패스워드찾기 버튼

	View.OnClickListener bHandler = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()) {
			case R.id.ivLoginButton:
				setResult(RESULT_OK);
				finish();
				break;
			case R.id.ivFindPassward:
				break;
			case R.id.ivJoinButton:
				Intent intent = new Intent(getApplicationContext(), JoinActivity.class);
				startActivityForResult(intent, JOININTENT);
				break;
			}			
		}
	};
		
	@Override
	// 부모가 하는일 없어 super 지워
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch(requestCode) {
		case JOININTENT:
			switch(resultCode) {
			case RESULT_OK:
				setResult(RESULT_OK);
				finish();
				break;
			case RESULT_CANCELED:
				break;
			}
			break;
		}
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		ivLoginButton = (ImageView)findViewById(R.id.ivLoginButton);
		ivJoinButton = (ImageView)findViewById(R.id.ivJoinButton);
		ivFindPassward = (ImageView)findViewById(R.id.ivFindPassward);
		
		ivLoginButton.setOnClickListener(bHandler);
		ivJoinButton.setOnClickListener(bHandler);
		ivFindPassward.setOnClickListener(bHandler);
	
	}

}
