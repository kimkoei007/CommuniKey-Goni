package com.communicationkey.helper;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

import com.communicationkey.debug.Comm;
import com.communicationkey.item.AllTable;
import com.communicationkey.service.BluetoothConnectService;

public class FriendHelper extends SQLiteOpenHelper {

	static ArrayList<AllTable> friendAllInfo = null;
	
	public FriendHelper(Context context, String name, CursorFactory factory,
			int version) {
		// 생성자1 추가해 생성자가 2개 있는데 위에꺼 쉬운 것만 사용하자
		// 1번 context 2번 db명임 꼭 .db를 붙혀줘야 된다! 3번은 아직 적용되는 것이 없다 null
		// 4번은 버전 Shared에 저장해 놓고 그 값을 가져와서 올리고 올리는 것
		// 5번째는 내가 초기입력할 데이터야!
		
		super(context, name, factory, version);
	}
	
	public FriendHelper(Context context, String name, CursorFactory factory,
			int version, ArrayList<AllTable> info) {
		// 생성자1 추가해 생성자가 2개 있는데 위에꺼 쉬운 것만 사용하자
		// 1번 context 2번 db명임 꼭 .db를 붙혀줘야 된다! 3번은 아직 적용되는 것이 없다 null
		// 4번은 버전 Shared에 저장해 놓고 그 값을 가져와서 올리고 올리는 것
		// 5번째는 내가 초기입력할 데이터야!
		
		super(context, name, factory, version);
		friendAllInfo = info;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// 어플깔고 딱 1번만 실행돼 !
		Comm.LOG("FriendHelper onCreate()");
		
		String sql = "create table friend(_id integer primary key autoincrement, " 
				+ "userId text, userName text, userTel text, userMac text, UNIQUE(userId));";
		try {
			db.execSQL(sql);
			
			Comm.LOG("FriendallInfo :" + friendAllInfo);
			
//			for(int i = 0; i < friendAllInfo.size(); i++)
//				db.execSQL("insert into member(userId, userName, userTel, userMac)"
//						+ "values(" + friendAllInfo.get(i).getUserId() + "," "));
			
			for(int i = 0; i < friendAllInfo.size(); i++) {
				ContentValues values = new ContentValues();
				
				values.put("userId", friendAllInfo.get(i).getUserId());
				values.put("userName", friendAllInfo.get(i).getUserName());
				values.put("userTel", friendAllInfo.get(i).getUserTel());
				values.put("userMac", friendAllInfo.get(i).getUserMac());
				
				long id = db.insert("friend", null, values);
				
				if (id > 0)
					Comm.LOG("FriendHelper onCreate Insert Success");
				else 
					Comm.LOG("FriendHelper onCreate Insert Error!");
				
				Comm.LOG("onCreate Table Values : " + values);
			}
			
			Comm.LOG("FriendHelper Table Create Success");
		} catch(SQLException e) {
			Comm.LOG("FriendHelper Create Table Error : " + e);
		}

	}

	@Override
	public void onOpen(SQLiteDatabase db) {
		super.onOpen(db);
		
		Comm.LOG("FriendHelper onOpen");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}

}
