package Parser;

import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import Item.UserTel;

public class JSONParser {

	public static ArrayList<UserTel> JSONParser(String jsonString) {
		UserTel userTel = null;
		ArrayList<UserTel> userTels = new ArrayList<UserTel>();
		JSONObject jTemp = null;
		JSONArray jArray = null;

		Object obj = JSONValue.parse(jsonString);

		try {
			jArray = (JSONArray) obj;

			for (int i = 0; i < jArray.size(); i++) {
				userTel = new UserTel();
				jTemp = (JSONObject) jArray.get(i);

				userTel.setUserTel(jTemp.get("phone").toString());

				userTels.add(userTel);
			}

		} catch (Exception e) {

			System.out.println("JSONParsor Error : " + e);
		}
		return userTels;
	}
}
