package Item;

import java.io.Serializable;

public class DeviceTable implements Serializable {

	private static final long serialVersionUID = 572229060850857216L;

	private String userMac;
	private String deviceId;
	private String authority;
	private String period;

	@Override
	public String toString() {
		return "DeviceTable [userMac=" + userMac + ", deviceId=" + deviceId
				+ ", authority=" + authority + ", period=" + period + "]";
	}

	public String getUserMac() {
		return userMac;
	}

	public void setUserMac(String userMac) {
		this.userMac = userMac;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

}