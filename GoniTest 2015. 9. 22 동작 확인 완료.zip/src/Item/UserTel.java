package Item;

import java.io.Serializable;

public class UserTel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4980319048126411434L;
	private String userTel;

	public String getUserTel() {
		return userTel;
	}

	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}

	@Override
	public String toString() {
		return "userInfo [userTel=" + userTel + "]";
	}

}
