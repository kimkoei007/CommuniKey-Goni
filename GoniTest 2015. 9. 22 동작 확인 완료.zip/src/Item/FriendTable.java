package Item;

import java.io.Serializable;

public class FriendTable implements Serializable {

	private static final long serialVersionUID = -5176270163330587836L;
	private String userId;
	private String friendId;

	@Override
	public String toString() {
		return "FriendTable [userId=" + userId + ", friendId=" + friendId + "]";
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFriendId() {
		return friendId;
	}

	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}

}
