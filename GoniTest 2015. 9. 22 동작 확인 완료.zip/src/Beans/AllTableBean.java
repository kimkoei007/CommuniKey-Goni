package Beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Item.AllTable;

public class AllTableBean {

	Connection conn = null;
	PreparedStatement pstmt = null;

	String DB_URL = "jdbc:oracle:thin:@61.105.185.71:1521:orcl";
	String DB_USER = "DBTESTER";
	String DB_PASSWORD = "1122334455";
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";

	public boolean insertJoinApp(AllTable data) {
		connect();

		String sql = "insert into ALLTABLE(userId, userPw, userName, userTel, userMac) values(?, ?, ?, ?, ?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, data.getUserId());
			pstmt.setString(2, data.getUserPw());
			pstmt.setString(3, data.getUserName());
			pstmt.setString(4, data.getUserTel());
			pstmt.setString(5, data.getUserMac());
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("insert DB Error : " + e);
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	public AllTable selectAllTableDBUserId(String userId) {
		connect();

		String sql = "select * from ALLTABLE where userId = ?";
		AllTable dbData = null;

		try {
			dbData = new AllTable();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);

			// 찾는 아이디가 없으면 에러가 여기에 뜹니다.
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			dbData.setUserId(rs.getString("userId"));
			dbData.setUserPw(rs.getString("userPw"));
			dbData.setUserName(rs.getString("userName"));
			dbData.setUserTel(rs.getString("userTel"));
			dbData.setUserMac(rs.getString("userMac"));
			rs.close();
		} catch (SQLException e) {
			System.out.println("아이디가 없습니다. : " + e);
			return null;
		} finally {
			disconnect();
		}
		return dbData;
	}

	public ArrayList<AllTable> selectAllTableDBList() {
		connect();
		ArrayList<AllTable> datas = new ArrayList<AllTable>();

		String sql = "select * from ALLTABLE";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				AllTable dbData = new AllTable();

				dbData.setUserId(rs.getString("userId"));
				dbData.setUserPw(rs.getString("userPw"));
				dbData.setUserName(rs.getString("userName"));
				dbData.setUserTel(rs.getString("userTel"));
				dbData.setUserMac(rs.getString("userMac"));
				datas.add(dbData);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return datas;
	}

	void connect() {
		try {
			Class.forName(jdbc_driver);

			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
