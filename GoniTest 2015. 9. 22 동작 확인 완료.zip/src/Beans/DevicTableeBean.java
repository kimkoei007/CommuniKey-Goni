package Beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Item.AllTable;
import Item.DeviceTable;

public class DevicTableeBean {

	Connection conn = null;
	PreparedStatement pstmt = null;

	String DB_URL = "jdbc:oracle:thin:@61.105.185.71:1521:orcl";
	String DB_USER = "DBTESTER";
	String DB_PASSWORD = "1122334455";
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";

	// Number가 0이되면 DB에서 삭제를 해줘야지! 
		// 
		public void deleteNumber(DeviceTable dtInfo) {
			connect();
			
			String sql = "delete from DEVICETABLE where DeviceId = ? and UserMac = ?";
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, dtInfo.getDeviceId());
				pstmt.setString(2, dtInfo.getUserMac());
				pstmt.executeUpdate();
				
			} catch (Exception e) {
				System.out.println("deleteNumber Error : " + e);
			} finally {
				disconnect();
			}
		}
		
		// 횟수를 한번 사용했으면 서버에 횟수를 1개 줄여줘야하지 않을까?
		// 횟수를 줄여주기 위한 Update!!
		public void updateMinusNumber(DeviceTable dtInfo, int nNumberCount) {
			connect();
		
			String sql = "update DEVICETABLE set Period = ? where DeviceId = ? and UserMac = ? ";
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, nNumberCount + "");
				pstmt.setString(2, dtInfo.getDeviceId());
				pstmt.setString(3, dtInfo.getUserMac());
				pstmt.executeUpdate();
				
			} catch (Exception e) {
				System.out.println("updateMinusNumber Error : " + e);
			} finally {
				disconnect();
			}
		}
		

		// 서버에 자주 접속하면 시간이 오래걸려 그러니까 일단 모든 DeviceTable의 Data를 전부 가져와야해
		public ArrayList<DeviceTable> allSelectDeviceTable() {
			connect();

			// 반환할 Data야
			ArrayList<DeviceTable> alDeviceTable = new ArrayList<DeviceTable>();
			DeviceTable doDeviceTable;

			String sql = "select * from DEVICETABLE";

			try {
				pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					doDeviceTable = new DeviceTable();

					doDeviceTable.setDeviceId(rs.getString("deviceId"));
					doDeviceTable.setUserMac(rs.getString("userMac"));
					doDeviceTable.setAuthority(rs.getString("authority"));
					doDeviceTable.setPeriod(rs.getString("period"));
					
					alDeviceTable.add(doDeviceTable);
				}
				
				rs.close();

			} catch (Exception e) {
				System.out.println("allSelectDeviceTable Error : " + e);
				disconnect();
				return null;
			} finally {
				disconnect();
			}

			return alDeviceTable;
		}

		// 친구에게 키를 전달하는 과정임 이걸 통해서 디바이스 테이블에 친구를 입력시키는 것
		public void insertDeviceTableFriendId(String deviceId, String userMac,
				String authority, String period) {
			connect();

			String sql = "insert into DEVICETABLE"
					+ "(deviceId, userMac, authority, period, num) values(?, ?, ?, ?, DEVICENUM.nextval)";

			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, deviceId);
				pstmt.setString(2, userMac);
				pstmt.setString(3, authority);
				pstmt.setString(4, period);
				pstmt.executeUpdate();
			} catch (Exception e) {
				System.out.println("insert DB Error : " + e);
			} finally {
				disconnect();
			}
		}

		// 내 맥주소를 통해서 내가 등록되어있는 디바이스의 이름들을 뽑아올꺼야!!
		// 그 뽑아온 디바이스를 클릭해서 키 전송할 떄 사용할 것이고
		// GridView에 사용되는 소스야!
		public JSONArray searchMyDevice(String myMac) {
			connect();

			JSONObject object = null;
			JSONArray jArray = new JSONArray();

			String sql = "select * from DEVICETABLE where userMac=?";
			String result = "";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, myMac);

				ResultSet rs = pstmt.executeQuery();

				// rs.next();
				//
				// System.out.println("deviceId" + rs.getString("deviceId"));

				while (rs.next()) {
					object = new JSONObject();
					object.put("deviceId", rs.getString("deviceId"));

					System.out.println("JSONObejct : " + object);

					if (object != null)
						jArray.add(object);
				}

			} catch (Exception e) {
				System.out.println("맞는 아이디가 없습니다. : " + e);
			} finally {
				disconnect();
			}
			return jArray;
		}

		// 디바이스 아이디와 유저맥을 통해서 디바이스 테이블에 접근해서 내 문을 열게 해주는 것
		public String searchDevice(String deviceId, String userMac) {
			connect();

			String sql = "select * from DEVICETABLE where deviceId=? and userMac=?";

			ArrayList<DeviceTable> datas = new ArrayList<DeviceTable>();
			String result = "";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, deviceId);
				pstmt.setString(2, userMac);

				ResultSet rs = pstmt.executeQuery();

				rs.next();

			} catch (Exception e) {
				System.out.println("맞는 아이디가 없습니다. : " + e);
				result = "doNotOpen";
				disconnect();
				return result;
			} finally {
				disconnect();
			}
			// 아이디를 찾고 맥도 맞으면
			result = "doOpen";
			return result;
		}

		void connect() {
			try {
				Class.forName(jdbc_driver);

				conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		void disconnect() {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
