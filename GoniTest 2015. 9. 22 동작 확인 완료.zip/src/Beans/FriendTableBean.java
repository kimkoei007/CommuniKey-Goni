package Beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.json.simple.JSONObject;

import Item.AllTable;
import Item.FriendTable;

public class FriendTableBean {

	Connection conn = null;
	PreparedStatement pstmt = null;

	String DB_URL = "jdbc:oracle:thin:@61.105.185.71:1521:orcl";
	String DB_USER = "DBTESTER";
	String DB_PASSWORD = "1122334455";
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";

	// 친구들의 모든 목록을 일단 서버 한번 접속해서 가져와야 덜 느리니까
	// 이 데이터를 토대로 JSP내에서 친구 비교를 해야 느리지 않을 것
	public ArrayList<AllTable> serachAllTableInfo() {
		connect();

		ArrayList<AllTable> alFriends = new ArrayList<AllTable>();

		String sql = "select * from ALLTABLE";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				AllTable dbData = new AllTable();

				dbData.setUserId(rs.getString("userId"));
				dbData.setUserPw(rs.getString("userPw"));
				dbData.setUserName(rs.getString("userName"));
				dbData.setUserTel(rs.getString("userTel"));
				dbData.setUserMac(rs.getString("userMac"));
				alFriends.add(dbData);
			}
			rs.close();
			pstmt.close();
			conn.close();

		} catch (SQLException e) {
			System.out.println("JSON Friend All Info Error : " + e);
			disconnect();
			return null;
		} finally {
			disconnect();
		}

		return alFriends;
	}

	public JSONObject searchFriendAllInfo(String friendId) {
		connect();
		JSONObject data = null;

		String sql = "select * from ALLTABLE where userId = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, friendId);
			ResultSet rs = pstmt.executeQuery();

			rs.next();

			// 데이터가 없으면 만들지 말아야지.
			data = new JSONObject();

			// 내전화번호부로 찾아야지 그러니까 친구목록에 넣어줘야 해
			data.put("userId", rs.getString("userId"));
			data.put("userName", rs.getString("userName"));
			data.put("userTel", rs.getString("userTel"));
			data.put("userMac", rs.getString("userMac"));

			rs.close();

		} catch (SQLException e) {
			System.out.println("JSON Friend All Info Error : " + e);
			disconnect();
			return null;
		} finally {
			disconnect();
		}
		return data;
	}

	// 전화번호를 기반으로 친구목록을 가져왔어. 그걸 FriendTable에 입력하면 돼
	public void insertFriendTable(FriendTable data) {
		connect();

		String sql = "insert into FRIENDTABLE(userId, friendId, num) values(?, ?,f_num.nextval)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, data.getUserId());
			pstmt.setString(2, data.getFriendId());
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("insert Friend DB Error : " + e);
		} finally {
			disconnect();
		}
	}

	public FriendTable searchFriend(String userTel, String userId) {
		connect();
		FriendTable data = null;

		userTel = userTel.replace("-", "");

		String sql = "select * from ALLTABLE where userTel = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userTel);
			ResultSet rs = pstmt.executeQuery();

			rs.next();

			// 데이터가 없으면 만들지 말아야지.
			data = new FriendTable();

			// 내전화번호부로 찾아야지 그러니까 친구목록에 넣어줘야 해
			data.setFriendId(rs.getString("userId"));

			// 내 아이디를 받아왔으니까 여기에 집어 넣어야 해
			data.setUserId(userId);

			rs.close();

		} catch (SQLException e) {
			System.out.println("serarchFriend Error : " + e);
			disconnect();
			return null;
		} finally {
			disconnect();
		}
		System.out.println("data가 채워지나?");
		return data;
	}

	void connect() {
		try {
			Class.forName(jdbc_driver);

			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
